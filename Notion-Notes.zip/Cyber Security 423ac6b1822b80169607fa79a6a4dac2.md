# Cyber Security

[Assessment Methodologies: Enumeration CTF 1](Cyber%20Security/Assessment%20Methodologies%20Enumeration%20CTF%201%20423ac6b1822b80449dd9ea924ac7cb7c.md)

[NETWORK SERVICE ](Cyber%20Security/NETWORK%20SERVICE%20423ac6b1822b80a2b70ffb4f8aefd9dd.md)

[ **Metasploit Framework — Complete Professional Training Course**](Cyber%20Security/Metasploit%20Framework%20%E2%80%94%20Complete%20Professional%20Train%20423ac6b1822b80729480c1afe0a99d8b.md)

[PowerShell & CMD for Pentesters](Cyber%20Security/PowerShell%20&%20CMD%20for%20Pentesters%20423ac6b1822b80fb96c0f7403e09aed6.md)

[Open Ports & Protocols — Complete Pentest & SOC Course](Cyber%20Security/Open%20Ports%20&%20Protocols%20%E2%80%94%20Complete%20Pentest%20&%20SOC%20Co%20423ac6b1822b808fa92af12a13dc4c91.md)

[Pickle Rick Writeup](Cyber%20Security/Pickle%20Rick%20Writeup%20423ac6b1822b80cf87b5ecd0b3a39f88.md)

[Windows for Cybersecurity — Complete Course (Red Team + Blue Team)](Cyber%20Security/Windows%20for%20Cybersecurity%20%E2%80%94%20Complete%20Course%20(Red%20T%20423ac6b1822b806eadc0ea07e102bb1e.md)

[dc-2 walkthrough ](Cyber%20Security/dc-2%20walkthrough%2040aac6b1822b80a186a0d70cda82e25e.md)

[Welcome to Notion](Cyber%20Security/Welcome%20to%20Notion%2040aac6b1822b80f98ce4d10fc06f4e55.md)

[To Do List](Cyber%20Security/To%20Do%20List%2040aac6b1822b80c4a4c1d8e2e625fc9a.md)