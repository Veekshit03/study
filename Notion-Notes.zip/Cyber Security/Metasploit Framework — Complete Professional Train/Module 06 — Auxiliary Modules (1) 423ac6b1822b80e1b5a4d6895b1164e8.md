# Module 06 — Auxiliary Modules (1)

> 🟡 **Intermediate Level** | Scanning, enumeration, and brute forcing without exploitation
> 

---

# 📟 Auxiliary Modules

## 🤔 What Are Auxiliary Modules?

**Auxiliary modules** do everything EXCEPT exploit vulnerabilities. They are used for:

- Port scanning
- Service version detection
- Vulnerability scanning
- Brute force attacks
- Enumeration
- Fuzzing
- Denial of service testing
- Server simulation

---

## 🚀 How to Use Auxiliary Modules

```bash
# General workflow:
msf6 > use auxiliary/scanner/smb/smb_version
msf6 auxiliary(scanner/smb/smb_version) > show options
msf6 auxiliary(scanner/smb/smb_version) > set RHOSTS 192.168.1.0/24
msf6 auxiliary(scanner/smb/smb_version) > set THREADS 20
msf6 auxiliary(scanner/smb/smb_version) > run

# Note: Auxiliary modules use 'run' not 'exploit'
# (though 'exploit' also works)
```

---

## 🔍 Port Scanning

```bash
# TCP SYN port scanner:
msf6 > use auxiliary/scanner/portscan/tcp
msf6 auxiliary(scanner/portscan/tcp) > set RHOSTS 192.168.1.20
msf6 auxiliary(scanner/portscan/tcp) > set PORTS 1-1000
msf6 auxiliary(scanner/portscan/tcp) > set THREADS 50
msf6 auxiliary(scanner/portscan/tcp) > run

# SYN scan (faster, requires root):
msf6 > use auxiliary/scanner/portscan/syn
msf6 auxiliary(scanner/portscan/syn) > set RHOSTS 192.168.1.0/24
msf6 auxiliary(scanner/portscan/syn) > set PORTS 22,80,443,445,3389
msf6 auxiliary(scanner/portscan/syn) > run

# ICMP ping sweep (find live hosts):
msf6 > use auxiliary/scanner/discovery/udp_sweep
msf6 > use auxiliary/scanner/portscan/arp
```

---

## 🌐 SMB Enumeration

```bash
# Detect SMB version and OS:
msf6 > use auxiliary/scanner/smb/smb_version
msf6 auxiliary(scanner/smb/smb_version) > set RHOSTS 192.168.1.20
msf6 auxiliary(scanner/smb/smb_version) > run
# Output: Windows XP / Samba 3.0.20-Debian

# Check for MS17-010 (EternalBlue) vulnerability:
msf6 > use auxiliary/scanner/smb/smb_ms17_010
msf6 auxiliary(scanner/smb/smb_ms17_010) > set RHOSTS 192.168.1.20
msf6 auxiliary(scanner/smb/smb_ms17_010) > run
# Output: Host is LIKELY VULNERABLE to MS17-010!

# Enumerate SMB shares:
msf6 > use auxiliary/scanner/smb/smb_enumshares
msf6 auxiliary(scanner/smb/smb_enumshares) > set RHOSTS 192.168.1.20
msf6 auxiliary(scanner/smb/smb_enumshares) > run

# Enumerate SMB users:
msf6 > use auxiliary/scanner/smb/smb_enumusers
msf6 auxiliary(scanner/smb/smb_enumusers) > set RHOSTS 192.168.1.20
msf6 auxiliary(scanner/smb/smb_enumusers) > run
```

---

## 🔑 SSH Brute Force

```bash
# SSH login brute force:
msf6 > use auxiliary/scanner/ssh/ssh_login
msf6 auxiliary(scanner/ssh/ssh_login) > set RHOSTS 192.168.1.20
msf6 auxiliary(scanner/ssh/ssh_login) > set RPORT 22
msf6 auxiliary(scanner/ssh/ssh_login) > set USERNAME msfadmin
msf6 auxiliary(scanner/ssh/ssh_login) > set PASS_FILE /usr/share/wordlists/rockyou.txt
# Or use a username list:
msf6 auxiliary(scanner/ssh/ssh_login) > set USER_FILE /usr/share/metasploit-framework/data/wordlists/common_users.txt
msf6 auxiliary(scanner/ssh/ssh_login) > set THREADS 4
msf6 auxiliary(scanner/ssh/ssh_login) > set VERBOSE true
msf6 auxiliary(scanner/ssh/ssh_login) > run

# Output on success:
# [+] 192.168.1.20:22 - Success: 'msfadmin:msfadmin' 'uid=1000(msfadmin)'
```

---

## 🌐 HTTP Enumeration

```bash
# Detect HTTP server version:
msf6 > use auxiliary/scanner/http/http_version
msf6 auxiliary(scanner/http/http_version) > set RHOSTS 192.168.1.20
msf6 auxiliary(scanner/http/http_version) > run

# Directory/file brute force:
msf6 > use auxiliary/scanner/http/dir_scanner
msf6 auxiliary(scanner/http/dir_scanner) > set RHOSTS 192.168.1.20
msf6 auxiliary(scanner/http/dir_scanner) > set DICTIONARY /usr/share/metasploit-framework/data/wordlists/directory.txt
msf6 auxiliary(scanner/http/dir_scanner) > run

# WordPress scanner:
msf6 > use auxiliary/scanner/http/wordpress_login_enum
msf6 > use auxiliary/scanner/http/wordpress_xmlrpc_login

# Apache mod_userdir enumeration:
msf6 > use auxiliary/scanner/http/apache_userdir_enum
```

---

## 🗄️ MySQL Enumeration

```bash
# MySQL version detection:
msf6 > use auxiliary/scanner/mysql/mysql_version
msf6 auxiliary(scanner/mysql/mysql_version) > set RHOSTS 192.168.1.20
msf6 auxiliary(scanner/mysql/mysql_version) > run

# MySQL login brute force:
msf6 > use auxiliary/scanner/mysql/mysql_login
msf6 auxiliary(scanner/mysql/mysql_login) > set RHOSTS 192.168.1.20
msf6 auxiliary(scanner/mysql/mysql_login) > set USERNAME root
msf6 auxiliary(scanner/mysql/mysql_login) > set PASS_FILE /usr/share/metasploit-framework/data/wordlists/unix_passwords.txt
msf6 auxiliary(scanner/mysql/mysql_login) > set BLANK_PASSWORDS true
msf6 auxiliary(scanner/mysql/mysql_login) > run

# MySQL SQL query execution (if you have credentials):
msf6 > use auxiliary/admin/mysql/mysql_sql
msf6 auxiliary(admin/mysql/mysql_sql) > set RHOSTS 192.168.1.20
msf6 auxiliary(admin/mysql/mysql_sql) > set USERNAME root
msf6 auxiliary(admin/mysql/mysql_sql) > set PASSWORD ""
msf6 auxiliary(admin/mysql/mysql_sql) > set SQL "show databases"
msf6 auxiliary(admin/mysql/mysql_sql) > run
```

---

## 📊 Useful Auxiliary Modules Quick Reference

| Module | Purpose |
| --- | --- |
| `scanner/portscan/tcp` | TCP port scan |
| `scanner/smb/smb_version` | SMB version detection |
| `scanner/smb/smb_ms17_010` | EternalBlue check |
| `scanner/ssh/ssh_login` | SSH brute force |
| `scanner/ftp/ftp_login` | FTP brute force |
| `scanner/http/http_version` | HTTP server detection |
| `scanner/mysql/mysql_login` | MySQL brute force |
| `scanner/vnc/vnc_login` | VNC brute force |
| `scanner/telnet/telnet_login` | Telnet brute force |
| `scanner/smtp/smtp_enum` | SMTP user enumeration |

---

> ✅ **Auxiliary modules mastered! Now learn exploit modules.**
> 

---

## Enhancement — Rank System & Check-Before-Exploit (added)

Seven-tier reliability ranking shown in `search` results:

| Rank | Meaning |
| --- | --- |
| Excellent | Never crashes the service (SQLi, command exec, file inclusion — inherently safe) |
| Great | Default target auto-detects correct config |
| Good | Default target covers the common case, no auto-detect |
| Normal | Reliable against a specific version, no auto-detect/broad default |
| Average | Unreliable but >50% success |
| Low | <50% success |
| Manual | Essentially a DoS or needs heavy manual config, ≤15% success |

Higher rank ≠ guaranteed success; lower rank ≠ guaranteed failure — it's a starting point, not a promise.

### Choosing the Right Scanner (pattern, not memorization)

1. Identify an open port/service from scan results
2. `search type:auxiliary <service_name>`
3. `info` to understand what it actually does
4. Set parameters, run

Finding an FTP service on 21? `search type:auxiliary ftp` surfaces anonymous-login tests, version detection, and brute-force modules — the discovery process is the transferable skill, not memorizing module names. This connects directly to the Analysing a Finding & Confirming Exploitability module in the Exploitation & Weaponisation course, which covers the broader methodology this scanning sits inside.

---

## Enhancement — SMTP Enumeration, Nessus & WMAP (added, from the INE MSF course deck)

### SMTP Enumeration

SMTP (port 25, also 465/587) enumeration identifies mail server version and, more usefully, valid user accounts via the VRFY/EXPN commands many servers still expose:

```bash
msf6 > search type:auxiliary smtp
msf6 > use auxiliary/scanner/smtp/smtp_enum
msf6 auxiliary(scanner/smtp/smtp_enum) > set RHOSTS 192.168.1.20
msf6 auxiliary(scanner/smtp/smtp_enum) > set USER_FILE /usr/share/metasploit-framework/data/wordlists/unix_users.txt
msf6 auxiliary(scanner/smtp/smtp_enum) > run
```

Valid usernames found here feed directly into SSH/FTP brute-force targeting — a classic enumeration chain.

### Vulnerability Scanning with Nessus

Nessus (Tenable) is a dedicated, proprietary vulnerability scanner — broader and more authoritative than MSF's own auxiliary scanners for CVE-level detection. The free tier (Nessus Essentials) scans up to 16 IPs.

**Integration workflow:** run a Nessus scan externally → export results → import into MSF's database for correlation against modules:

```bash
msf6 > db_import /path/to/nessus_scan.nessus
msf6 > vulns
```

Nessus gives you the CVE and severity; MSF's `vulns` table then lets you cross-reference which of those CVEs have a matching exploit module — Nessus identifies, MSF exploits.

### Web App Scanning with WMAP

WMAP is an MSF plugin (not a separate tool) for automated web application vulnerability scanning, fully integrated into msfconsole:

```bash
msf6 > load wmap
msf6 > wmap_sites -a http://192.168.1.20
msf6 > wmap_targets -t http://192.168.1.20
msf6 > wmap_run -t
```

Useful for a first-pass web app sweep without leaving msfconsole, though dedicated tools (Burp, Nikto) generally give deeper coverage — WMAP's value is staying inside the same session and database as your network-side findings.

**SOC/VAPT relevance:** this three-tool layering (MSF auxiliary → Nessus → WMAP) reflects how real engagements combine a fast internal scanner, an authoritative CVE scanner, and a web-specific scanner rather than relying on one tool for everything.