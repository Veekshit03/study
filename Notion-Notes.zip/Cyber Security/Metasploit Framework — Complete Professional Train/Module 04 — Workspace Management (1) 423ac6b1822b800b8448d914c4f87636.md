# Module 04 — Workspace Management (1)

> 🟢 **Beginner Level** | Organize penetration tests with separate workspaces
> 

---

# 📁 Workspace Management

## 🤔 What Are Workspaces?

**Workspaces** are isolated containers within the Metasploit database. Each workspace has its own:

- Host records
- Service records
- Credential records
- Session history
- Loot files

This lets you run **multiple engagements simultaneously** without mixing data.

```
┌──────────────────────────────────────────┐
│         PostgreSQL Database                 │
│                                           │
│  ┌──────────┐ ┌─────────┐ ┌─────────┐  │
│  │ default  │ │ client_A │ │ lab_test │  │
│  │workspace │ │workspace │ │workspace │  │
│  └──────────┘ └─────────┘ └─────────┘  │
└──────────────────────────────────────────┘
```

---

## 📜 Complete Workspace Commands

```bash
# List all workspaces (* = currently active):
msf6 > workspace
# Output:
# * default
#   client_A
#   lab_metasploitable

# Create a new workspace:
msf6 > workspace -a lab_metasploitable
# [*] Added workspace: lab_metasploitable

# Switch to a workspace:
msf6 > workspace lab_metasploitable
# [*] Workspace: lab_metasploitable

# Rename a workspace:
msf6 > workspace -r old_name new_name

# Delete a workspace (and ALL its data!):
msf6 > workspace -d lab_metasploitable

# Show help for workspace command:
msf6 > workspace -h
```

---

## 🎯 Practical Workspace Workflow

```bash
# Start a new engagement:
msf6 > workspace -a metasploitable2_lab
msf6 > workspace metasploitable2_lab

# Run your scans (data saves to this workspace):
msf6 > db_nmap -sV 192.168.1.20

# All findings stored in this workspace:
msf6 > hosts
msf6 > services

# Switch to another engagement:
msf6 > workspace -a client_B
msf6 > workspace client_B
# Clean slate - no data from previous workspace!

# Come back to first engagement:
msf6 > workspace metasploitable2_lab
# All your data is still here!
```

---

> ✅ **Workspaces mastered! Now learn to search for the right modules.**
> 

---

## Enhancement — Querying Workspace Data (added)

Once `db_nmap` has populated a workspace, use these to avoid retyping IPs and to leverage prior scans automatically:

```bash
msf6 > hosts                    # every host the DB knows about
msf6 > services                 # every open port + service across all hosts
msf6 > services -S webfs        # filter services by name
msf6 > creds                    # credentials collected (e.g. from smb_login brute-force)
```

**The time-saver:** `hosts -R` (inside a loaded module) auto-populates RHOSTS from every host in the current workspace — `services -S smb -R` narrows that to only hosts with a matching service. No manual IP entry, no transcription errors, critical at multi-host scale.

```bash
msf6 auxiliary(scanner/smb/smb_login) > hosts -R
msf6 auxiliary(scanner/smb/smb_login) > show options
 RHOSTS   10.0.0.5   yes   The target host(s)...
```

**Import external scans:** `db_import /path/to/scan.xml` pulls in Nmap XML (also Nessus, Qualys, Burp output); `db_export` pulls workspace data back out for reporting/archival.