# Module 03 — PostgreSQL Database Configuration (1)

> 🟢 **Beginner Level** | Connect Metasploit to its database for persistent tracking
> 

---

# 🗄️ PostgreSQL Database Configuration

## 🤔 Why Does Metasploit Need a Database?

Without a database, Metasploit works but **loses all data when you close msfconsole**. With PostgreSQL connected, Metasploit stores:

- **Hosts** — Discovered IP addresses and hostnames
- **Services** — Open ports and running services
- **Vulnerabilities** — CVEs and findings
- **Credentials** — Captured usernames and passwords
- **Sessions** — Active and historical sessions
- **Loot** — Files and data extracted from targets
- **Workspaces** — Separate project environments

---

## ✅ Step 1: Start PostgreSQL Service

```bash
# Start PostgreSQL:
sudo systemctl start postgresql

# Enable auto-start on boot:
sudo systemctl enable postgresql

# Check status:
sudo systemctl status postgresql
# Should show: Active: active (running)
```

---

## ✅ Step 2: Initialize Metasploit Database

```bash
# Initialize the MSF database (creates DB, user, config):
sudo msfdb init

# Expected output:
# [+] Starting database
# [+] Creating database user 'msf'
# [+] Creating databases 'msf'
# [+] Creating databases 'msf_test'
# [+] Creating configuration file '/usr/share/metasploit-framework/config/database.yml'
# [+] Creating initial database schema
```

**Other msfdb commands:**

```bash
msfdb start    # Start database
msfdb stop     # Stop database
msfdb status   # Check status
msfdb reinit   # Delete and recreate database
msfdb delete   # Remove database completely
```

---

## ✅ Step 3: Verify Database Connection Inside msfconsole

```bash
# Launch msfconsole:
msfconsole -q

# Check database connection:
msf6 > db_status
# Good output:
# [*] Connected to msf. Connection type: postgresql.
# [*] Database started by: postgres

# If not connected:
msf6 > db_connect
# or manually:
msf6 > db_connect msf:password@127.0.0.1/msf
```

---

## 📊 Database Commands Reference

```bash
# Show all database commands:
msf6 > help database

# List all hosts discovered:
msf6 > hosts
msf6 > hosts -c address,name,os_name,purpose

# List all services:
msf6 > services
msf6 > services -p 80,443,22    # Filter by port
msf6 > services -s http         # Filter by service name

# List credentials:
msf6 > creds
msf6 > creds -u admin           # Filter by username

# List vulnerabilities:
msf6 > vulns

# List loot (extracted files/data):
msf6 > loot

# Import Nmap scan results:
msf6 > db_import /tmp/nmap_scan.xml

# Export database to XML:
msf6 > db_export -f xml /tmp/pentest_export.xml

# Run Nmap from within MSF and save to DB:
msf6 > db_nmap -sV -p 1-1000 192.168.1.20
```

---

## 💾 Database Config File Location

```bash
cat /usr/share/metasploit-framework/config/database.yml

# Contents:
# production:
#   adapter: postgresql
#   database: msf
#   username: msf
#   password: [auto-generated]
#   host: 127.0.0.1
#   port: 5432
#   pool: 75
#   timeout: 5
```

---

> ✅ **Database configured! Now learn workspace management.**
> 

---

## Enhancement — DB Setup Walkthrough & Verification (added)

```bash
sudo msfdb init
msf6 > db_status
[*] Connected to msf. Connection type: postgresql.
```

Kali-specific: `sudo msfdb init` handles PostgreSQL user creation internally — older tutorials recommending `sudo -u postgres msfdb init` are the upstream (non-Kali) approach and will fail or misconfigure on Kali.

If `db_status` shows "No connection": `sudo systemctl start postgresql` then re-run `msfdb init`.

**Why it matters (SOC/VAPT relevance):** every scan run through the DB (`db_nmap`, `hosts -R`, `services -R`) becomes queryable for every other module in the session — this is what separates ad-hoc single-host testing from a structured multi-host engagement where 50 hosts need tracked state.