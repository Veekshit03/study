# Module 17 — Blue Team Detection & Defense (1)

> 🔴 **Advanced Level** | How defenders detect and respond to Metasploit-based attacks
> 

---

# 🛡️ Blue Team Detection & Defense

## 🤔 Why Blue Teams Need to Know Metasploit

The best defenders understand exactly how Metasploit works. Every attack pattern it generates becomes a **detection signature** for the defense team.

---

## 🗺️ Defense-in-Depth Architecture

```
INTERNET
    │
    ▼
┌────────────────────────┐
│  Firewall / IPS (Layer 1) │  ← Block known exploit ports
└────────────┬───────────┘
             │
             ▼
┌────────────────────────┐
│  IDS / NIDS (Layer 2)    │  ← Detect Meterpreter traffic
└────────────┬───────────┘
             │
             ▼
┌────────────────────────┐
│  EDR / AV (Layer 3)      │  ← Detect Meterpreter in memory
└────────────┬───────────┘
             │
             ▼
┌────────────────────────┐
│  SIEM (Layer 4)          │  ← Correlate all events
└────────────────────────┘
```

---

## 🔍 Detecting Metasploit Network Traffic

### Meterpreter Traffic Signatures

```
Meterpreter reverse_tcp:
- TCP connection from target to attacker on port 4444 (default)
- If HTTPS: SSL certificate is self-signed with unusual fields
- Packet size patterns are distinctive
- High entropy encrypted data (looks random)

Detection Indicators:
- Outbound connections to unusual ports (4444, 4445, 5555)
- Self-signed certificates from internal hosts
- Long-lived encrypted sessions from workstations
- DNS queries to unusual external domains
```

### Snort / Suricata Rules for Metasploit

```
# Detect Meterpreter reverse TCP handshake:
alert tcp $HOME_NET any -> $EXTERNAL_NET 4444 (
  msg:"Possible Meterpreter Reverse Shell - Port 4444";
  flow:established,to_server;
  sid:9000001;
  rev:1;
)

# Detect EternalBlue SMB exploit:
alert tcp any any -> $HOME_NET 445 (
  msg:"Possible EternalBlue MS17-010 Exploit Attempt";
  flow:established,to_server;
  content:"|00 00 00 85 ff 53 4d 42|"; offset:4; depth:8;
  sid:9000002;
  rev:1;
)

# Detect Metasploit User-Agent:
alert http any any -> $HTTP_SERVERS any (
  msg:"Metasploit Scanner User-Agent Detected";
  http_header;
  content:"Mozilla/4.0 (compatible\; MSIE 6.0\; Windows NT 5.1)";
  sid:9000003;
  rev:1;
)
```

---

## 📜 Log Analysis — What to Look For

### Windows Event Logs to Monitor

```
Event ID 4624  - Successful logon (look for unusual source IPs)
Event ID 4625  - Failed logon (brute force detection)
Event ID 4688  - New process created (cmd.exe, powershell.exe by unexpected parent)
Event ID 4697  - Service installed (persistence mechanism)
Event ID 4648  - Logon with explicit credentials (pass-the-hash)
Event ID 1102  - Audit log cleared (attacker covering tracks!)
Event ID 7045  - New service installed
```

### Linux Logs to Monitor

```bash
# Auth failures:
tail -f /var/log/auth.log | grep Failed

# New cron jobs:
crontab -l
ls -la /etc/cron*

# Unusual processes:
ps aux | grep -v root | grep -v $(whoami)

# Network connections:
netstat -tulpn
ss -tulpn

# Recently modified files:
find / -newer /tmp/baseline -type f 2>/dev/null

# Unusual SUID files:
find / -perm -4000 -type f 2>/dev/null
```

---

## 🚔 Detecting Specific Metasploit Exploits

### EternalBlue (MS17-010) Detection

```bash
# Signs of EternalBlue attack:
# - Multiple SMB connections from one source
# - Connections to port 445 with malformed packets
# - Windows Error Reporting crashes on SMB service
# - SYSTEM-level process creation after SMB activity

# Check Windows for patches:
wmic qfe list | findstr KB4012212
# If missing: VULNERABLE!

# Block:
# - Disable SMBv1
# - Block port 445 at firewall
# - Apply MS17-010 patch
```

### Meterpreter In-Memory Detection

```bash
# Meterpreter runs in memory, injected into a process
# Signs:
# - Legitimate process (notepad.exe, explorer.exe) has unusual network connections
# - Process memory contains shellcode patterns
# - Process making outbound connections on unusual ports

# Detection tools:
# - CrowdStrike Falcon (EDR)
# - Microsoft Defender for Endpoint
# - Volatility (memory forensics)

# Using Volatility to detect Meterpreter in memory dump:
volatility -f memory.dmp --profile=Win7SP1x64 netscan
volatility -f memory.dmp --profile=Win7SP1x64 malfind
```

---

## 📡 SIEM Detection Rules

### Splunk Query for Metasploit Brute Force

```
index=windows EventCode=4625
| stats count by Source_Network_Address, Account_Name
| where count > 10
| sort -count
| alert
```

### Splunk Query for Suspicious Process Creation

```
index=windows EventCode=4688
| where (Process_Name="*cmd.exe" OR Process_Name="*powershell.exe")
  AND (Creator_Process_Name="*iexplore.exe" 
    OR Creator_Process_Name="*winword.exe"
    OR Creator_Process_Name="*excel.exe")
| table _time, ComputerName, Creator_Process_Name, Process_Name, CommandLine
```

---

## 🔒 Hardening to Prevent Metasploit Attacks

### Network Hardening

```bash
# Disable SMBv1 (prevents EternalBlue):
Set-SmbServerConfiguration -EnableSMB1Protocol $false

# Block dangerous ports at firewall:
# Block inbound: 139, 445 (SMB) from external
# Block inbound: 23 (Telnet)
# Block inbound: 512-514 (rexec, rlogin, rsh)
# Block inbound: 1099 (Java RMI)
# Block inbound: 6667 (IRC)

# Disable unused services:
sudo systemctl disable telnet
sudo systemctl disable rsh
sudo systemctl disable rlogin
```

### System Hardening

```bash
# Keep systems patched:
sudo apt update && sudo apt upgrade -y       # Linux
Windows Update: Enable automatic updates      # Windows

# Change default credentials IMMEDIATELY:
# vsftpd, MySQL root, PostgreSQL postgres, VNC

# Use strong passwords:
# Minimum 12 characters, mixed case, numbers, symbols

# Enable host-based firewall:
sudo ufw enable
sudo ufw deny 23      # Block Telnet
sudo ufw deny 512     # Block rexec
```

---

## 🚔 SOC Incident Response for Metasploit Attacks

```
Step 1: DETECT
  Alert fires (IDS/SIEM/EDR)
  SOC analyst reviews alert

Step 2: TRIAGE
  Confirm it's a real attack (not false positive)
  Identify affected systems
  Assess impact

Step 3: CONTAIN
  Isolate affected host from network
  Block attacker IP at firewall
  Preserve logs and memory dump for forensics

Step 4: ERADICATE
  Kill malicious processes
  Remove persistence mechanisms
  Remove dropped files
  Change all passwords

Step 5: RECOVER
  Restore from clean backup
  Apply missing patches
  Re-enable system after verification

Step 6: LESSONS LEARNED
  Root cause analysis
  What controls failed?
  Update detection rules
  Security awareness training
```

---

> ✅ **Course complete! You now have full Metasploit knowledge from both attacker and defender perspectives.**
> 

---

## 🏆 Course Completion Summary

| Module | Topic | Status |
| --- | --- | --- |
| 01 | Metasploit Architecture | ✅ Complete |
| 02 | Installation & Setup | ✅ Complete |
| 03 | PostgreSQL Configuration | ✅ Complete |
| 04 | Workspace Management | ✅ Complete |
| 05 | Searching Modules | ✅ Complete |
| 06 | Auxiliary Modules | ✅ Complete |
| 07 | Exploit Modules | ✅ Complete |
| 08 | Payloads | ✅ Complete |
| 09 | Meterpreter | ✅ Complete |
| 10 | Post Exploitation | ✅ Complete |
| 11 | Privilege Escalation | ✅ Complete |
| 12 | msfvenom | ✅ Complete |
| 13 | Automation & Scripts | ✅ Complete |
| 14 | Nmap Integration | ✅ Complete |
| 15 | Practical Labs | ✅ Complete |
| 16 | Red Team Methodology | ✅ Complete |
| 17 | Blue Team Detection | ✅ Complete |