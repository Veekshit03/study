# Module 01 — Metasploit Architecture (1)

> 🟢 **Beginner Level** | Understand the framework before using it
> 

---

# 🏗️ Metasploit Architecture

## 🤔 What is Metasploit?

**Metasploit Framework (MSF)** is the world's most widely used open-source penetration testing framework. Created by H.D. Moore in 2003, acquired by Rapid7, it provides:

- A unified platform for developing and executing exploits
- A massive library of 2,000+ modules
- Automation of complex attack chains
- Post-exploitation capabilities
- An extensible Ruby-based architecture

---

## 🗺️ Architecture Overview

```
┌─────────────────────────────────────────────────┐
│                INTERFACES                        │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐  │
│  │  msfconsole │ │  msfcli   │ │ Armitage  │ │   Web UI  │  │
│  │  (CLI)      │ │ (scripts) │ │  (GUI)    │ │ (Pro)    │  │
│  └─────────┘ └─────────┘ └─────────┘ └─────────┘  │
└─────────────────────────┬──────────────────────┘
                         │
┌─────────────────────┴──────────────────────┐
│              CORE FRAMEWORK                    │
│                                               │
│  Rex (Ruby Extension Library)                 │
│  Framework Core (Module Manager)              │
│  Framework Base (Plugin System)               │
└─────────────────────┬──────────────────────┘
                         │
        ┌───────────────┴───────────────┐
        │                               │
┌───────┴───────┐       ┌───────┴───────┐
│    MODULES           │       │    DATABASE         │
│                     │       │                    │
│  exploits/          │       │  PostgreSQL         │
│  auxiliary/         │       │  Hosts, Services    │
│  payloads/          │       │  Vulns, Loots       │
│  post/              │       │  Sessions, Creds    │
│  encoders/          │       │  Workspaces         │
│  nops/              │       └────────────────────┘
│  evasion/           │
└─────────────────────┘
```

---

## 📚 Module Types Explained

### 1. Exploits

Code that takes advantage of a specific vulnerability to gain access.

```
exploits/windows/smb/ms17_010_eternalblue   ← EternalBlue for Windows
exploits/multi/handler                      ← Generic payload handler
exploits/unix/ftp/vsftpd_234_backdoor       ← vsftpd backdoor 
```

### 2. Auxiliary

Non-exploit modules for scanning, fuzzing, brute forcing, and information gathering.

```
auxiliary/scanner/smb/smb_version           ← SMB version scanner
auxiliary/scanner/portscan/tcp              ← TCP port scanner
auxiliary/scanner/ssh/ssh_login             ← SSH brute forcer
auxiliary/scanner/http/http_version         ← HTTP server detector 
```

### 3. Payloads

Code that runs on the target AFTER exploitation.

```
payloads/singles/       ← Self-contained (no stage needed)
payloads/stagers/       ← Sets up connection channel
payloads/stages/        ← The actual payload downloaded via stager 

Examples:
windows/meterpreter/reverse_tcp       ← Staged Meterpreter
windows/shell_reverse_tcp             ← Single reverse shell
linux/x86/meterpreter/reverse_tcp     ← Linux Meterpreter 
```

### 4. Post

Modules run AFTER gaining access. Privilege escalation, persistence, data collection.

```
post/multi/recon/local_exploit_suggester  ← Find local privesc
post/windows/gather/hashdump              ← Dump password hashes 
post/linux/gather/checkvm                 ← Check if in VM
```

### 5. Encoders

Encode payloads to evade antivirus signatures.

```
encoders/x86/shikata_ga_nai   ← Polymorphic XOR encoder  
encoders/x64/xor_dynamic      ← 64-bit XOR encoder
```

### 6. Evasion

Modules specifically for AV/EDR evasion. 

```
evasion/windows/applocker_evasion_msbuild 
```

---

## 📊 Module Directory Structure

```bash
/usr/share/metasploit-framework/modules/  
├── auxiliary/
│   ├── scanner/
│   ├── brute/
│   └── server/
├── exploits/
│   ├── windows/
│   ├── linux/
│   ├── multi/
│   └── unix/
├── payloads/
│   ├── singles/
│   ├── stagers/
│   └── stages/
├── post/
├── encoders/
├── nops/
└── evasion/   
```

---

## 🔄 Exploitation Flow

```
1. RECON
   Identify target IP, OS, open ports, services  
        │
        v
2. MODULE SELECTION
   Search and select appropriate exploit module
        │
        v
3. CONFIGURATION
   Set RHOSTS, LHOST, LPORT, payload
        │
        v
4. LAUNCH EXPLOIT
   run / exploit
        │
        v
5. SESSION OPENED
   Meterpreter / Shell session established
        │
        v
6. POST EXPLOITATION
   Gather info, escalate privileges, pivot
```

---

> ✅ **Architecture understood! Now install and set up Metasploit.**
> 

---

## Enhancement — The Exploit Chain & Module Naming (added)

### The Exploit Chain — Physical Security Analogy

A vulnerability is a broken lock on a warehouse door. An exploit is the act of pulling that door open. A payload is what the intruder does once inside — steal inventory, plant a listener, or just photograph the break-in to prove it happened.

| Term | Definition |
| --- | --- |
| Vulnerability | A design/coding/config flaw — creates *opportunity* for harm, doesn't cause it directly |
| Exploit | Code that triggers the vulnerability in a controlled way |
| Payload | Code that runs on target *after* exploit succeeds |

An exploit without a payload triggers the flaw but produces nothing useful; a payload without an exploit has no way to reach the target. MSF's architecture pairs the right exploit with the right payload.

```mermaid
flowchart LR
    V[Vulnerability: broken lock] --> E[Exploit: pulls door open]
    E --> P[Payload: what happens inside]
    P --> S1[Single/Stageless: all-in-one]
    P --> S2[Staged: stager + downloaded stage]
```

### Payload Naming Convention — Staged vs Stageless

The separator between shell type and connection method tells you everything:

| Payload | Separator | Type |
| --- | --- | --- |
| `windows/x64/shell_reverse_tcp` | `_` underscore | **Single/Stageless** — entire payload in one package |
| `windows/x64/shell/reverse_tcp` | `/` slash | **Staged** — small stager connects, then downloads full stage |

General path structure: `<platform>/<architecture>/<payload_type><separator><connection_method>`

### Seven Module Categories — Quick Reference

| Category | Role |
| --- | --- |
| Exploits | Target a specific vuln on a specific platform (~2,600 modules — largest category) |
| Auxiliary | Everything non-exploit: scanners, fingerprinters, brute-forcers, sniffers |
| Payloads | Code executed on target post-exploit (~1,700 modules) |
| Post | Run through an existing session: hash dumping, enum, pivoting |
| Encoders | Transform payload bytes — bad-character removal, NOT reliable AV evasion |
| NOPs | No-op sleds for predictable memory landing in buffer overflows — auto-handled |
| Evasion | Purpose-built bypass attempts (Defender/AppLocker) — smallest category (~12 modules) |

> **Security note:** encoding (e.g. `x86/shikata_ga_nai`) is not encryption and is not reliable AV evasion against modern heuristic/behavioural/AMSI-based detection — its legitimate use is bad-character removal and format compliance, covered in depth in Module 12.
> 

**SOC/VAPT relevance:** recognizing the naming pattern at a glance lets you predict a payload's network footprint (one connection vs stager-then-stage) before you even run it — useful for choosing payloads against egress-filtered targets.

---

## Enhancement — Editions, PTES Mapping & File System (added, from the INE MSF course deck)

### Metasploit Editions

| Edition | Type | Notes |
| --- | --- | --- |
| Metasploit Pro | Commercial | Full GUI, team collaboration, reporting |
| Metasploit Express | Commercial | Lighter commercial tier |
| Metasploit Framework (Community) | Free/open-source | What this course uses — CLI-driven via msfconsole |
| MSFcli | Discontinued (2015) | Old command-line scripting utility; its functionality now lives entirely inside msfconsole |

### PTES — Mapping Penetration Testing Phases to MSF

The Penetration Testing Execution Standard (PTES) gives a standard phase breakdown; MSF implements each phase with specific tooling:

| PTES Phase | MSF Implementation |
| --- | --- |
| Information Gathering & Enumeration | Auxiliary modules |
| Vulnerability Scanning | Auxiliary modules, Nessus integration |
| Exploitation | Exploit modules & payloads |
| Post Exploitation | Meterpreter |
| Privilege Escalation | Post-exploitation modules, Meterpreter |
| Maintaining Persistent Access | Persistence modules |

```mermaid
flowchart LR
    A[Info Gathering] --> B[Vuln Scanning]
    B --> C[Exploitation]
    C --> D[Post Exploitation]
    D --> E[Privilege Escalation]
    E --> F[Persistence]
```

### MSF File System Locations

```bash
# System-wide modules (Linux):
/usr/share/metasploit-framework/modules

# User-specific custom modules:
~/.msf4/modules
```

Dropping a custom module script into `~/.msf4/modules`, matching the module-type path structure (`exploits/`, `auxiliary/`, etc.), makes it available to `search` and `use` without restarting msfconsole in most cases — useful for private or in-development modules.