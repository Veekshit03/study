# Module 02 — Installation & Setup (1)

> 🟢 **Beginner Level** | Get Metasploit running on Kali Linux
> 

---

# ⚙️ Installation & Setup

## 💡 Good News: Pre-installed on Kali!

If you're using **Kali Linux** (strongly recommended), Metasploit Framework is already installed. Just launch it!

---

## ✅ Step 1: Verify Installation

```bash
# Check Metasploit version:
msfconsole --version

# Expected output:
# Framework Version: 6.x.x-dev

# Also check:
which msfconsole
# Output: /usr/bin/msfconsole
```

---

## 🔄 Step 2: Update Metasploit

Always use the latest version for the most current exploits:

```bash
# Update Kali packages (updates Metasploit too):
sudo apt update && sudo apt upgrade metasploit-framework -y

# Or update just Metasploit:
sudo apt install metasploit-framework -y

# Inside msfconsole:
msf6 > msfupdate
```

---

## 💻 Step 3: Fresh Install on Debian/Ubuntu

```bash
# Download official installer:
curl https://raw.githubusercontent.com/rapid7/metasploit-omnibus/master/config/templates/metasploit-framework-wrappers/msfupdate.erb > msfinstall

# Make executable:
chmod 755 msfinstall

# Run installer:
./msfinstall

# Start PostgreSQL (required):
sudo systemctl start postgresql

# Initialize MSF database:
msfdb init

# Launch:
msfconsole
```

---

## 🚀 Step 4: Launch msfconsole

```bash
# Launch Metasploit:
msfconsole

# Launch quietly (skip banner):
msfconsole -q

# Launch and run a command directly:
msfconsole -q -x "use auxiliary/scanner/portscan/tcp; set RHOSTS 192.168.1.0/24; run"

# Launch with a resource script:
msfconsole -r /path/to/script.rc
```

**On launch, you'll see:**

```
                                                  
  Metasploit Park, System Security Interface      
  Version 4.0.5, Alpha E                         
                                                  
          .’“”“‘.
    .---. /       \ .---.               
msf6 >
```

---

## 🏗️ msfconsole Key Commands Reference

```bash
# Get help:
msf6 > help
msf6 > ?

# Show version:
msf6 > version

# Clear screen:
msf6 > clear

# Exit:
msf6 > exit
msf6 > quit

# Run a shell command from within msfconsole:
msf6 > shell
msf6 > !ls /tmp

# Show all sessions:
msf6 > sessions
msf6 > sessions -l

# Interact with session #1:
msf6 > sessions -i 1

# Kill session #1:
msf6 > sessions -k 1
```

---

## 📊 Metasploit Editions Comparison

| Edition | Cost | Features |
| --- | --- | --- |
| Metasploit Framework | Free | Full CLI access, all modules |
| Metasploit Community | Free | Web UI, limited features |
| Metasploit Pro | Paid | Automation, reporting, campaigns |

> 💡 For this course, **Metasploit Framework (free)** is all you need.
> 

---

> ✅ **Installation complete! Now configure the PostgreSQL database.**
>