# Module 05 — Searching Modules (1)

> 🟢 **Beginner Level** | Find the right module for any situation
> 

---

# 🔍 Searching Modules

## 🤔 The search Command

Metasploit has **2,000+ modules**. The `search` command helps you find exactly what you need quickly.

---

## 📜 Basic Search Syntax

```bash
# Search by keyword:
msf6 > search smb
msf6 > search ssh
msf6 > search ftp
msf6 > search http
msf6 > search mysql

# Search by CVE number:
msf6 > search cve:2017-0144
msf6 > search cve:2021-44228     # Log4Shell
msf6 > search cve:2019-0708      # BlueKeep

# Search by module type:
msf6 > search type:exploit
msf6 > search type:auxiliary
msf6 > search type:post
msf6 > search type:payload

# Search by platform:
msf6 > search platform:windows
msf6 > search platform:linux
msf6 > search platform:android

# Search by name:
msf6 > search name:eternalblue
msf6 > search name:vsftpd 

# Combine search terms:
msf6 > search type:exploit platform:windows smb
msf6 > search type:auxiliary name:scanner ssh
```

---

## 📊 Understanding Search Results

```
msf6 > search smb 

Matching Modules
================

   #   Name                                          Disclosure Date  Rank       Check  Description
   -   ----                                          ---------------  ----       -----  -----------
   0   auxiliary/scanner/smb/smb_ms17_010            2017-03-14       normal     Yes    MS17-010 SMB RCE Detection
   1   auxiliary/scanner/smb/smb_version             .                normal     No     SMB Version Detection
   2   exploit/windows/smb/ms17_010_eternalblue      2017-03-14       excellent  Yes    EternalBlue SMB RCE
   3   exploit/windows/smb/ms17_010_psexec           2017-03-14       normal     Yes    EternalBlue SMB via PsExec
   4   exploit/windows/smb/ms08_067_netapi           2008-10-28       great      Yes    MS08-067 NetAPI
```

**Column Explanations:**

| Column | Meaning |
| --- | --- |
| # | Module index number |
| Name | Module path (use this with `use`) |
| Disclosure Date | When vulnerability was publicly disclosed |
| Rank | Reliability rating |
| Check | Whether module has a check() function |
| Description | Brief description |

**Rank Values (best to worst):**

```
excellent  → Reliable, won't crash service
great      → Default auto-selected options work
good       → Works in common scenarios
normal     → Standard behavior
average    → Sometimes doesn't work
low        → Often fails
manual     → Requires lots of configuration
```

---

## 🎯 Selecting and Using Modules

```bash
# Use by full path:
msf6 > use exploit/windows/smb/ms17_010_eternalblue

# Use by search result number (after searching):
msf6 > use 2

# Show current module info:
msf6 exploit(windows/smb/ms17_010_eternalblue) > info

# Show options:
msf6 exploit(windows/smb/ms17_010_eternalblue) > options
msf6 exploit(windows/smb/ms17_010_eternalblue) > show options

# Show advanced options:
msf6 exploit(windows/smb/ms17_010_eternalblue) > show advanced

# Show available payloads for current exploit:
msf6 exploit(windows/smb/ms17_010_eternalblue) > show payloads

# Go back to main prompt:
msf6 exploit(windows/smb/ms17_010_eternalblue) > back
```

---

## ℹ️ The info Command — Deep Dive

```bash
msf6 > info exploit/windows/smb/ms17_010_eternalblue

# Output shows:
# Name: MS17-010 EternalBlue SMB Remote Windows Kernel Pool Corruption
# Module: exploit/windows/smb/ms17_010_eternalblue
# Platform: Windows
# Arch: x64
# Privileged: Yes
# License: Metasploit Framework License (BSD)
# Rank: Average
# Disclosed: 2017-03-14
#
# Available targets:
#   0  Windows 7 and Server 2008 R2 (x64) All Service Packs
#
# Check supported: Yes
#
# Basic options:
#   Name      Required  Default  Description
#   RHOSTS    yes                Target IP(s)
#   RPORT     yes       445      Target SMB port
#
# References:
#   CVE-2017-0144
#   MS17-010
```

---

> ✅ **Module searching mastered! Now explore auxiliary modules.**
> 

---

## Enhancement — Prompt Reference & Session Workflow (added)

Five distinct prompts you'll encounter — always check which one you're at before debugging a command failure:

| Prompt | Context | What you can do |
| --- | --- | --- |
| `root@host~#` | Regular Linux terminal | Standard Linux commands only |
| `msf6 >` | msfconsole, no module loaded | Global commands: `search`, `use`, `sessions`, `setg` — NOT `set`/`exploit` |
| `msf6 exploit(...) >` | Module loaded | Full module commands: `set`, `show options`, `exploit`, `check`, `back` |
| `meterpreter >` | Active Meterpreter session | `sysinfo`, `getuid`, `hashdump`, `shell`, `background` |
| `C:\Windows\system32>` | OS shell on target | Every command executes ON the target |

**Common mistake:** trying `set RHOSTS` from `msf6 >` with no module loaded, or typing Linux commands into a Meterpreter session.

### set vs setg

`set` is local to the current module — lost on `back`/`use` elsewhere. `setg` persists across every module for the session. Rule of thumb: `setg` for values constant across the engagement (RHOSTS, LHOST); `set` for module-specific values (RPORT, PAYLOAD, SESSION).

### help command

Always check `help search`, `help set`, etc. before guessing syntax — msfconsole documents every command inline.