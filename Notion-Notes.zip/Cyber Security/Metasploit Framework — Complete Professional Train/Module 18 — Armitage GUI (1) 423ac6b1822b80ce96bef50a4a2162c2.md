# Module 18 — Armitage GUI (1)

> 🟢 Beginner Level | Visualizing and automating MSF through a GUI
> 

---

# 🖥️ Armitage — Metasploit's GUI Front-End

## What Is Armitage?

Armitage is a free, Java-based graphical front-end for the Metasploit Framework, developed by Raphael Mudge. It simplifies network discovery, exploitation, and post-exploitation by giving you a visual, point-and-click layer over msfconsole's functionality — it does not replace MSF; it drives it.

Armitage ships pre-packaged with Kali Linux and most other pentesting distributions.

## Prerequisites

Armitage requires the Metasploit Framework database and backend services (`msfrpcd`) to be running before it can connect:

```bash
sudo systemctl start postgresql
sudo msfdb init
sudo msfrpcd -P your_password -S
armitage
```

If Armitage can't connect, the first thing to check is whether `msfrpcd` is actually running — Armitage is just a client to that RPC service, so a database or RPC daemon problem shows up as an Armitage connection failure, not an Armitage bug.

## What Armitage Gives You

| Capability | What it means in practice |
| --- | --- |
| **Visualize targets** | Hosts appear as icons on a canvas; compromised hosts are marked differently from uncompromised ones at a glance |
| **Automate port scanning** | Right-click a host or subnet → Nmap scan, results populate the canvas automatically |
| **Automate exploitation** | "Attacks → Find Attacks" cross-references discovered services against matching exploit modules, flagging likely-vulnerable hosts |
| **Automate post exploitation** | Right-click a compromised host for a menu of common Meterpreter actions (migrate, screenshot, hashdump, etc.) without typing commands |

## Typical Workflow

```mermaid
flowchart LR
    A[Add targets to canvas] --> B[Nmap scan via right-click]
    B --> C[Find Attacks - cross-ref exploits]
    C --> D[Launch exploit via GUI]
    D --> E[Compromised host icon changes]
    E --> F[Right-click post-exploit menu]
```

1. Add hosts to the canvas (manually or via a scan)
2. Right-click → Scan (runs Nmap/MSF scanners under the hood)
3. Attacks → Find Attacks — Armitage checks every discovered service against matching exploit modules
4. Right-click a flagged host → the suggested exploit, configure options in a dialog instead of `set` commands
5. On success, the host icon changes (often to a "compromised" visual state) and a Meterpreter console tab opens
6. Right-click the compromised host for post-exploitation actions — these are still just MSF post modules running underneath

## Why This Matters

**For learning:** Armitage is a useful way to *see* the relationship between hosts, services, and exploits before you're comfortable with msfconsole's text-only output — the canvas makes "which hosts are compromised" and "what's exploitable" visually obvious.

**For real engagements:** Armitage is genuinely useful for managing larger numbers of simultaneous sessions across many hosts, where a GUI's at-a-glance view beats scrolling through `sessions` output. It's less commonly used by experienced testers for single-target work, where msfconsole is faster once you know the commands.

**Security implication:** Armitage traffic and its underlying MSF RPC communication have known network signatures — defenders monitoring for Metasploit activity (see the Blue Team Detection & Defense module) should not assume a lack of visible msfconsole sessions means no MSF activity; Armitage-driven sessions look identical to msfconsole-driven ones from the target's perspective, since Armitage is just a client issuing the same underlying module calls.

## Important Points

- Armitage requires the MSF database AND `msfrpcd` running — two separate prerequisites, both must succeed
- "Find Attacks" suggests candidates; it does not confirm exploitability — the same check-before-exploit discipline from Module 06 still applies, Armitage just automates the *search*, not the *verification*
- A compromised-host icon in Armitage is backed by a real Meterpreter/shell session — everything you'd do from `sessions -i <id>` in msfconsole is available, just through right-click menus instead of typed commands