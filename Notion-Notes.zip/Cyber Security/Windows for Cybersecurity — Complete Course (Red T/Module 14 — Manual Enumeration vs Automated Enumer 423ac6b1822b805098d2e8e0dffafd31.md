# Module 14 — Manual Enumeration vs Automated Enumeration (1)

## Status: 🟢 Complete

## Manual vs Automated Enumeration

|  | Manual | Automated |
| --- | --- | --- |
| Strength | Deep understanding, adapts to odd environments | Speed, consistency, repeatability |
| Weakness | Slow, easy to miss something under pressure | False positives, misses context, can fail silently on permission errors |
| When to prefer | Learning, unusual/constrained environments, validating automated output | Repeated assessments, large estates, baseline sweeps |

Automation should **augment** manual understanding, not replace it — a script that fails due to missing permissions can silently under-report, so always sanity-check automated output against a few manual spot-checks.

## Script Library (beginner + advanced pattern)

Each script below follows: objective → prerequisites → source → explanation → execution → expected output → error handling → security considerations → real-world use.

### 1 — System Information Collection

```powershell
# Beginner
Get-ComputerInfo | Select-Object CsName, OsName, OsVersion, OsArchitecture

# Advanced (reusable function, error-handled)
function Get-HostSysInfo {
    [CmdletBinding()]
    param([string]$ComputerName = $env:COMPUTERNAME)
    try {
        $info = Get-CimInstance Win32_OperatingSystem -ComputerName $ComputerName -ErrorAction Stop
        [PSCustomObject]@{
            Host = $ComputerName; OS = $info.Caption; Build = $info.BuildNumber
            LastBoot = $info.LastBootUpTime
        }
    } catch { Write-Warning "Failed on $ComputerName: $_" }
}
```

**Security note:** feeds the Module 06 host profile; run read-only, low noise.

### 2 — User & Group Enumeration

```powershell
function Get-LocalAccountSummary {
    Get-LocalUser | Select-Object Name, Enabled, LastLogon
    Get-LocalGroupMember Administrators | Select-Object Name, ObjectClass
}
```

### 3 — Running Process Collection

```powershell
Get-Process | Select-Object Name, Id, CPU, WS | Sort-Object WS -Descending | Export-Csv processes.csv -NoTypeInformation
```

### 4 — Service Enumeration

```powershell
Get-Service | Where-Object Status -eq 'Running' | Select-Object Name, DisplayName, StartType
```

### 5 — Network Connection Enumeration

```powershell
Get-NetTCPConnection -State Established | Select-Object LocalAddress, RemoteAddress, RemotePort, OwningProcess
```

### 6 — Scheduled Task Enumeration

```powershell
Get-ScheduledTask | Where-Object State -ne 'Disabled' | Select-Object TaskName, TaskPath, State
```

### 7 — Installed Software Enumeration (fast, registry-based)

```powershell
Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* |
    Select-Object DisplayName, DisplayVersion, Publisher | Where-Object DisplayName
```

### 8 — Local Privilege Assessment (summary wrapper around Module 07)

```powershell
function Get-PrivescIndicators {
    whoami /priv
    Get-CimInstance Win32_Service | Where-Object { $_.PathName -notlike '"*' -and $_.PathName -like '* *' } |
        Select-Object Name, PathName
}
```

### 9 — Windows Event Log Collection

```powershell
Get-WinEvent -LogName Security -MaxEvents 100 | Where-Object Id -in 4624,4625,4672
```

### 10 — AD User Enumeration

```powershell
Get-ADUser -Filter * -Properties pwdlastset, description | Select-Object Name, pwdlastset, description
```

### 11 — AD Group Enumeration

```powershell
Get-ADGroup -Filter * | Select-Object Name, GroupCategory, GroupScope
```

### 12 — Privileged Account Reporting

```powershell
"Domain Admins","Enterprise Admins" | ForEach-Object {
    Get-ADGroupMember $_ | Select-Object Name, @{N='Group';E={$using:_}}
}
```

### 13 — Domain Computer Inventory

```powershell
Get-ADComputer -Filter * -Properties OperatingSystem, LastLogonDate |
    Select-Object Name, OperatingSystem, LastLogonDate
```

### 14 — Password Policy Reporting

```powershell
Get-ADDefaultDomainPasswordPolicy | Select-Object MinPasswordLength, LockoutThreshold, MaxPasswordAge
```

### 15 — Security Configuration Auditing (composite)

```powershell
function Invoke-SecurityAudit {
    [PSCustomObject]@{
        Defender = (Get-MpComputerStatus).AntivirusEnabled
        Firewall = (Get-NetFirewallProfile).Enabled -join ','
        ExecPolicy = Get-ExecutionPolicy
    }
}
```

## Error Handling Pattern (applies to all 15)

Wrap AD/remote-dependent scripts in `try/catch` and check `Get-Module -ListAvailable ActiveDirectory` before calling `Get-AD*` cmdlets — fail gracefully with a clear message rather than a raw exception.

## Lab Exercise

1. Run scripts 1, 4, and 8 against a lab host and save output to CSV.
2. Run scripts 10–14 against a lab AD domain.
3. Identify one case where automated output needs manual verification (e.g. a `Get-ADUser` property that's `$null` due to missing read permission vs. genuinely empty).

## Knowledge Check

1. Why can an automation script "silently under-report" instead of erroring outright?
2. What check should precede any `Get-AD*` cmdlet call in a portable script?
3. Why export to CSV/structured format rather than just printing to console for repeated assessments?