# Module 06 — Windows System Enumeration (1)

## Status: 🟢 Complete

Systematic enumeration means collecting the same categories of information every time, in order, so nothing is missed. For each category below: what to collect → why → command → how to interpret → security angle.

## Identity & OS

| What | Command | Why |
| --- | --- | --- |
| OS version/build | `systeminfo` / `Get-ComputerInfo` | Patch-level, known CVEs for that build |
| Hostname | `hostname` | Asset correlation |
| Domain membership | `systeminfo | findstr Domain` / `(Get-CimInstance Win32_ComputerSystem).Domain` | Tells you if AD enumeration (Modules 09–11) even applies |
| Current user | `whoami` | Baseline identity |
| User privileges | `whoami /priv` | Feeds Module 07 directly |

## Accounts & Groups

| What | Command |
| --- | --- |
| Local users | `Get-LocalUser` / `net user` |
| Local groups | `Get-LocalGroup` / `net localgroup` |
| Admin group members | `Get-LocalGroupMember Administrators` |

## Processes, Software, Services

| What | Command |
| --- | --- |
| Running processes | `Get-Process` / `tasklist` |
| Installed applications | `Get-CimInstance Win32_Product` (slow) or registry uninstall keys via `Get-ItemProperty HKLM:\...\Uninstall\*` (fast, preferred) |
| Installed updates | `Get-HotFix` / `wmic qfe list` |
| Services | `Get-Service` / `sc query` |
| Startup applications | `Get-CimInstance Win32_StartupCommand` |
| Scheduled tasks | `Get-ScheduledTask` |

## Environment & Shares

| What | Command |
| --- | --- |
| Environment variables | `Get-ChildItem Env:` / `set` |
| Shared folders | `Get-SmbShare` / `net share` |
| Open connections | `Get-NetTCPConnection` / `netstat -ano` |
| Firewall config | `Get-NetFirewallProfile` / `netsh advfirewall show allprofiles` |
| AV/Defender status | `Get-MpComputerStatus` |

## Interpreting Findings — Worked Example

```powershell
Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 5
```

If the most recent patch is many months old relative to the current date, that's a strong signal of unpatched, potentially exploitable vulnerabilities — but confirm the specific CVE applies to the exact build before treating it as a finding.

```mermaid
flowchart TD
    A[System Enumeration] --> B[Identity & OS]
    A --> C[Accounts & Groups]
    A --> D[Processes/Software/Services]
    A --> E[Environment & Shares]
    B & C & D & E --> F[Consolidated host profile]
    F --> G[Feeds Module 07: Privesc Enumeration]
```

## Lab Exercise

1. Run every command in this module against a lab VM and assemble a single "host profile" document.
2. Identify: OS build, domain status, local admins, top 5 newest patches, any shares.
3. Flag anything that looks unusual (e.g. a share with Everyone:Full Control, or Defender disabled).

## Knowledge Check

1. Why check domain membership before deciding whether AD enumeration applies?
2. What's a faster alternative to `Get-CimInstance Win32_Product` for listing installed software, and why is it preferred?
3. What single `Get-HotFix` detail hints at how current a system's patching is?