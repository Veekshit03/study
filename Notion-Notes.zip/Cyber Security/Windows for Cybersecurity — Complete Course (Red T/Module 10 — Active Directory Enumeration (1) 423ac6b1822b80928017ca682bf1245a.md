# Module 10 — Active Directory Enumeration (1)

## Status: 🟡 In progress — core content drafted

Prerequisite: a domain-joined box, with either the `ActiveDirectory` PowerShell module (RSAT) or raw LDAP when the module is unavailable.

## CMD-native Enumeration (no module needed)

| Command | Purpose |
| --- | --- |
| `whoami /all` | Includes domain group membership |
| `net user /domain` | Domain user list |
| `net user <user> /domain` | Target user detail |
| `net group /domain` | Domain groups |
| `net group "Domain Admins" /domain` | High-value group members |
| `net accounts /domain` | Password policy (min length, lockout, max age) |
| `nltest /dclist:<domain>` | List domain controllers |
| `nltest /domain_trusts` | Trust enumeration |
| `gpresult /r` | GPOs applied to the current machine |

## PowerShell AD Module

| Command | Purpose |
| --- | --- |
| `Get-ADDomain` | Domain info (SID, functional level, DN) |
| `Get-ADForest` | Forest info |
| `Get-ADDomainController -Filter *` | All domain controllers |
| `Get-ADUser -Filter * -Properties *` | Full user dump — the `Description` field often leaks credential hints |
| `Get-ADGroup -Filter *` | All groups |
| `Get-ADGroupMember "Domain Admins"` | Privileged group membership |
| `Get-ADComputer -Filter *` | Computer inventory |
| `Get-ADOrganizationalUnit -Filter *` | OU structure |
| `Get-ADTrust -Filter *` | Trust relationships |
| `Get-ADDefaultDomainPasswordPolicy` | Password policy detail |

### Security-relevant AD queries

- Kerberoastable accounts: `Get-ADUser -Filter {ServicePrincipalName -ne "$null"} -Properties ServicePrincipalName`
- AS-REP roastable accounts: `Get-ADUser -Filter {DoesNotRequirePreAuth -eq $true}`
- Unconstrained delegation: `Get-ADUser`/`Get-ADComputer -Filter {TrustedForDelegation -eq $true}`
- Constrained delegation: `-Filter {msDS-AllowedToDelegateTo -ne "$null"}`

## When the AD Module Isn't Installed

Use raw LDAP via the `[ADSI]` type accelerator or `System.DirectoryServices.DirectorySearcher` in PowerShell — works without RSAT, only needs domain authentication.

## Why Each Target Matters

| Enumeration target | Why it matters |
| --- | --- |
| User description fields | Often contain plaintext credential hints |
| Stale accounts (old `pwdlastset`) | Weak or forgotten credentials |
| SPN-bearing accounts | Kerberoast targets |
| Preauth-disabled accounts | AS-REP roast targets |
| Unconstrained delegation hosts | Can capture TGTs of anyone authenticating to them |
| Nested privileged groups | Hidden path to Domain Admin |
| Trust direction | Lateral movement across domains/forests |
| GPO / SYSVOL / NETLOGON scripts | Often hold legacy cleartext credentials (e.g. `cpassword`) |

```mermaid
flowchart TD
    A[Domain-joined low-priv user] --> B[CMD-native: whoami, net, nltest]
    A --> C[PowerShell AD module]
    A --> D[Raw LDAP via ADSI if module missing]
    B & C & D --> E[Users, groups, computers, trusts, policy]
    E --> F[Flag: SPNs, preauth-disabled, delegation, nested privilege]
    F --> G[Feed into Module 11: AD Security Assessment]
```

## Lab Exercises

*To be added — small lab AD domain (1 DC + 1–2 member hosts).*

## Knowledge Check

*To be added.*