# Module 03 — PowerShell Fundamentals (1)

## Status: 🟢 Complete

## Cmdlets & Verb-Noun Naming

PowerShell commands ("cmdlets") always follow `Verb-Noun` — `Get-Process`, `Set-ExecutionPolicy`, `New-Item`. Approved verbs (`Get`, `Set`, `New`, `Remove`, `Start`, `Stop`, `Invoke`, `Test`) make behavior predictable: `Get-*` reads, `Set-*` writes config, `Invoke-*` executes something.

**Aliases** are shortcuts (`ls` → `Get-ChildItem`, `ps` → `Get-Process`, `cat` → `Get-Content`) — convenient interactively, but scripts should use full cmdlet names for clarity and portability.

## Variables & Data Types

```powershell
$name = "Redteam"          # string
$count = 5                  # int
$items = @("a","b","c")     # array
$map = @{ key = "value" }   # hashtable
```

PowerShell is dynamically typed but everything is a .NET object — `$count.GetType()` tells you exactly what you're holding.

## Operators, Conditionals, Loops

```powershell
if ($count -gt 3) { "big" } else { "small" }

foreach ($item in $items) { Write-Output $item }

$i = 0
while ($i -lt 5) { $i++ }
```

Comparison operators are text-based: `-eq`, `-ne`, `-gt`, `-lt`, `-like`, `-match` (regex) — not `==`/`>` like C-family languages.

## Functions & Modules

```powershell
function Get-Square {
    param([int]$Number)
    return $Number * $Number
}
Get-Square -Number 4   # 16
```

Modules (`Import-Module ActiveDirectory`) bundle related cmdlets — this is how Module 10's AD cmdlets become available.

## Objects, Properties, Methods, and the Pipeline

This is PowerShell's defining difference from CMD: every cmdlet emits **objects**, not text.

```powershell
Get-Process | Where-Object { $_.CPU -gt 10 } | Sort-Object CPU -Descending | Select-Object Name, CPU, Id | Format-Table
```

```mermaid
flowchart LR
    A[Get-Process] -->|Process objects| B[Where-Object: filter by CPU]
    B -->|filtered objects| C[Sort-Object: order by CPU]
    C -->|sorted objects| D[Select-Object: pick fields]
    D -->|final objects| E[Format-Table: render]
```

`$_` refers to the current object in the pipeline. `.Property` reads a field; `.Method()` calls a behavior on the object (e.g. `$string.ToUpper()`).

## Error Handling

```powershell
try {
    Get-Item "C:\doesnotexist" -ErrorAction Stop
} catch {
    Write-Warning "File not found: $_"
}
```

## Help System & Providers

- `Get-Help <cmdlet> -Full` / `-Examples` — built-in documentation (run `Update-Help` once with internet access).
- `Get-Command -Verb Get -Noun *Process*` — discover cmdlets by pattern.
- Providers (`Get-PSDrive`) expose non-filesystem data (registry, cert store, environment) through the same filesystem-like cmdlets (`Get-ChildItem HKLM:\`).

## Practical Scenario

An analyst needs every process using more than 200MB RAM, sorted highest first, with just name/PID/memory shown:

```powershell
Get-Process | Where-Object { $_.WS -gt 200MB } | Sort-Object WS -Descending | Select-Object Name, Id, WS
```

This single readable pipeline replaces what would require several chained CMD commands and manual text parsing.

## Lab Exercise

1. Write a function `Get-Cube` that returns a number cubed.
2. Use `Get-Service | Where-Object Status -eq 'Running' | Select-Object Name, Status` and explain each pipeline stage.
3. Deliberately trigger an error (`Get-Item "Z:\nowhere"`) and wrap it in `try/catch`.

## Knowledge Check

1. What does the pipeline actually pass between cmdlets — text or objects?
2. What's the difference between an alias and a cmdlet's real name?
3. Why does `-eq` replace `==`?
4. What does a PowerShell "provider" let you do that CMD has no equivalent for?