# Module 15 — Defensive PowerShell and Windows Security Monitoring (1)

## Status: 🟢 Complete

## PowerShell Logging Capabilities

| Mechanism | What it captures | Enable via |
| --- | --- | --- |
| Module Logging | Pipeline execution details per module | GPO: Turn on Module Logging |
| Script Block Logging | Full de-obfuscated script block text, even from `-EncodedCommand` | GPO: Turn on PowerShell Script Block Logging → Event ID 4104 |
| Transcription | Full session transcript to a text file | GPO: Turn on PowerShell Transcription |

Script Block Logging is the single highest-value control here — it logs the *actual decoded content* of a script block, defeating simple Base64/obfuscation attempts at evading log review.

## Windows Security Monitoring Stack

- **Windows Defender** — real-time + signature/behavioral detection
- **Windows Firewall** — network-layer filtering, also logs blocked connections
- **Sysmon** — much richer process/network/registry/file event logging than built-in Windows logs
- **Windows Security log** — authentication, privilege use, account management events

## Key Event IDs

| Event ID | Meaning | Source |
| --- | --- | --- |
| 4624 | Successful logon | Security log |
| 4625 | Failed logon | Security log |
| 4672 | Special privileges assigned to new logon (admin-equivalent) | Security log |
| 4688 | New process created | Security log (requires command-line auditing enabled for full value) |
| 4697 | Service installed | Security log |
| 4698 | Scheduled task created | Security log |
| 4720 | User account created | Security log |
| 4728 | Member added to a global group | Security log |
| 4732 | Member added to a local group | Security log |
| 7045 | New service installed | System log |
| 4103 | Module logging execution details | PowerShell Operational log |
| 4104 | Script block text (incl. decoded obfuscated content) | PowerShell Operational log |

Each of these requires the relevant audit policy or GPO setting enabled — they are not all recorded by default out of the box.

## Investigation Patterns

- **Suspicious PowerShell execution**: 4688 showing `powershell.exe` with `-enc`/`-ExecutionPolicy Bypass` in the command line, correlated with 4104 for the decoded content.
- **Suspicious parent-child relationships**: Office apps (`winword.exe`, `excel.exe`) spawning `powershell.exe` or `cmd.exe` — a classic macro-dropper pattern, best seen via Sysmon Event ID 1.
- **Unusual network connections**: Sysmon Event ID 3 showing a process making outbound connections it has no legitimate reason to make.
- **Account/privilege changes**: 4720 (account created) + 4728/4732 (added to a privileged group) in close succession is a strong persistence signal.

```mermaid
flowchart TD
    A[PowerShell/process activity] --> B[Sysmon: process, network, registry]
    A --> C[Security log: logon, privilege, account events]
    A --> D[PowerShell Operational log: 4103/4104]
    B & C & D --> E[SIEM correlation]
    E --> F[Alert: suspicious pattern]
```

## Defensive Script Example

```powershell
Get-WinEvent -LogName "Microsoft-Windows-PowerShell/Operational" |
    Where-Object { $_.Id -eq 4104 -and $_.Message -match 'Invoke-Expression|FromBase64String' } |
    Select-Object TimeCreated, Message
```

## Lab Exercise

1. Enable Script Block Logging via local GPO in a lab VM.
2. Run an `-EncodedCommand` PowerShell call and locate its decoded content in Event ID 4104.
3. Write a `Get-WinEvent` query that flags any 4720 followed by a 4732 for the same account within 5 minutes.

## Knowledge Check

1. Why does Script Block Logging defeat simple Base64 obfuscation attempts?
2. What does Event ID 4672 specifically indicate that a plain 4624 does not?
3. Why is an Office app spawning `powershell.exe` treated as high-priority for investigation?