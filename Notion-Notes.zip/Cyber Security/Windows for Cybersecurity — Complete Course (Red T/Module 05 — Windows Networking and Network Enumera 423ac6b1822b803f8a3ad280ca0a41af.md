# Module 05 — Windows Networking and Network Enumeration (1)

## Status: 🟢 Complete

## Networking Concepts Primer

| Concept | What it is | Why it matters in security |
| --- | --- | --- |
| IP address / subnet mask | Host identity + network boundary | Defines what's "local" vs routed |
| Default gateway | Router for off-subnet traffic | Pivot point for network recon |
| DNS | Name → IP resolution | Enumeration source (zone info, SPNs) |
| DHCP | Automatic IP assignment | Rogue DHCP = MITM vector |
| ARP | IP → MAC resolution on local segment | ARP spoofing / cache poisoning target |
| TCP/UDP + ports | Transport-layer services | Service fingerprinting |
| Routing | How packets reach other networks | Lateral movement paths |
| Firewall | Traffic filtering | What's actually reachable |

## CMD Networking Commands

| Command | Purpose | Key flags |
| --- | --- | --- |
| `ipconfig` / `ipconfig /all` | IP config / full adapter detail | `/all` shows DNS, DHCP, MAC |
| `ping` | ICMP reachability test | `-n`, `-t` |
| `tracert` | Trace route to a host | `-d` (no DNS lookup, faster) |
| `nslookup` | DNS queries | interactive or one-shot |
| `arp -a` | Show ARP cache | reveals recently contacted local hosts |
| `route print` | Routing table | shows gateway, metric |
| `netstat -ano` | Connections + owning PID | pair with `tasklist` to resolve PID→name |
| `hostname` | Local hostname | quick ID |
| `getmac` | MAC address(es) | asset correlation |
| `pathping` | Combines ping + tracert stats | slower, more detail on packet loss per hop |

## PowerShell Networking Cmdlets

| Cmdlet | Purpose |
| --- | --- |
| `Test-Connection` | PowerShell's `ping`, object output |
| `Test-NetConnection` | Richer: tests a specific port (`-Port 445`) |
| `Resolve-DnsName` | DNS lookups, object output |
| `Get-NetIPAddress` | Structured IP/interface info |
| `Get-NetTCPConnection` | Active TCP sessions w/ owning PID inline |
| `Get-NetUDPEndpoint` | Active UDP listeners |
| `Get-NetRoute` | Routing table as objects |
| `Get-NetNeighbor` | PowerShell's ARP table equivalent |
| `Get-NetFirewallProfile` | Firewall profile status (Domain/Private/Public) |

## Practical Demonstration

```powershell
Test-NetConnection -ComputerName 10.10.10.5 -Port 445
Get-NetTCPConnection -State Established | Select-Object LocalAddress, RemoteAddress, RemotePort, OwningProcess
Get-NetFirewallProfile | Select-Object Name, Enabled
```

`Test-NetConnection -Port 445` instantly tells you whether SMB is reachable — one of the most common early pentest checks — without needing a separate port scanner for a single check.

## Recon vs Investigation: Same Data, Two Lenses

```mermaid
flowchart TD
    A[Network enumeration data] --> B[Attacker: map attack surface, find pivot points]
    A --> C[Defender: baseline normal traffic, spot anomalies]
```

A full `arp -a` dump helps an attacker understand what's alive on the segment; the same output helps a defender notice a MAC address that doesn't match their asset inventory.

## Lab Exercise

1. Run `ipconfig /all` and identify DNS server, DHCP server, and default gateway.
2. Use `Test-NetConnection` to check if ports 445, 3389, and 80 are open on a lab target.
3. Compare `netstat -ano` output to `Get-NetTCPConnection` for the same connection — confirm the owning PID matches.

## Knowledge Check

1. Why is `Test-NetConnection -Port` more useful for a quick service check than raw `ping`?
2. What local-segment attack does `arp -a` data relate to?
3. Name one field `Get-NetTCPConnection` provides directly that `netstat -ano` requires a second command to get.