# Module 17 — Advanced PowerShell for Security Professionals (1)

## Status: 🟢 Complete

## Advanced Functions & Parameter Validation

```powershell
function Get-RiskyService {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$ComputerName
    )
    Get-CimInstance Win32_Service -ComputerName $ComputerName |
        Where-Object { $_.PathName -notlike '"*' -and $_.PathName -like '* *' }
}
```

`[CmdletBinding()]` gives the function common parameters (`-Verbose`, `-ErrorAction`) like a built-in cmdlet.

## Script Modules & Custom Objects

Bundle related advanced functions into a `.psm1`, export only the intended ones via `Export-ModuleMember`, and return `[PSCustomObject]` results consistently so output composes cleanly with other cmdlets.

## Remoting, CIM Sessions, WinRM

```powershell
$session = New-CimSession -ComputerName dc01
Get-CimInstance Win32_OperatingSystem -CimSession $session
Invoke-Command -ComputerName dc01 -ScriptBlock { Get-Service } -Credential (Get-Credential)
```

PSRemoting (`Invoke-Command`, `Enter-PSSession`) runs over WinRM — understanding this is essential both for legitimate remote administration and for recognizing it as a lateral movement technique during an assessment.

## Background Jobs & Scheduled Automation

```powershell
Start-Job -ScriptBlock { Get-Process } | Wait-Job | Receive-Job
```

Useful for running multiple host queries concurrently rather than sequentially.

## REST API Interaction, JSON/CSV

```powershell
$resp = Invoke-RestMethod -Uri "https://api.example.local/hosts" -Headers @{Authorization="Bearer $token"}
$resp | ConvertTo-Json | Out-File hosts.json
Import-Csv inventory.csv | Where-Object Status -eq 'Active'
```

## Secure Credential Handling & SecretManagement

Never hardcode credentials in scripts. Use `Get-Credential` interactively, or the `Microsoft.PowerShell.SecretManagement` module with a vault provider for unattended automation — storing secrets in plaintext scripts is itself a finding worth flagging during assessments.

## Code Signing & Version Control

```powershell
Set-AuthenticodeSignature -FilePath script.ps1 -Certificate $cert
```

Signed scripts satisfy `AllSigned`/`RemoteSigned` policies legitimately; combine with Git-based version control for team script libraries, not ad hoc file copies.

## Pester Testing

```powershell
Describe "Get-RiskyService" {
    It "Returns an array" {
        (Get-RiskyService -ComputerName localhost) | Should -BeOfType [Array]
    }
}
```

Pester is PowerShell's testing framework — write tests for security-automation scripts the same way you would for production code, since a silently broken enumeration script gives false assurance.

## Performance Optimisation

Avoid `+=` on arrays in a loop (rebuilds the array each time); use a `[System.Collections.Generic.List[object]]` and `.Add()` instead for large result sets. Filter as early in the pipeline as possible (`-Filter` at the cmdlet level beats `Where-Object` after the fact, since the latter pulls all objects into memory first).

## Lab Exercise

1. Convert one of the Module 14 scripts into an advanced function with `[CmdletBinding()]` and parameter validation.
2. Run it remotely against a lab host via `Invoke-Command`.
3. Write one Pester test asserting the function returns the expected object type.

## Knowledge Check

1. Why does `[CmdletBinding()]` matter for a custom function's usability?
2. Why is hardcoding credentials in a script itself treated as a security finding?
3. Why does filtering earlier in a pipeline (cmdlet-level `-Filter`) outperform a later `Where-Object`?