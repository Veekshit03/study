# Module 09 — Active Directory Fundamentals (1)

## Status: 🟢 Complete

## What Is Active Directory, and Why Enterprises Use It

Active Directory (AD) is Microsoft's directory service for centrally managing users, computers, and permissions across a network. Instead of configuring 500 laptops individually, an admin manages one AD domain and every joined machine inherits policy, authentication, and group membership from it.

## Core Structural Concepts

| Term | Meaning |
| --- | --- |
| **Domain** | A managed collection of users/computers sharing a directory database |
| **Domain Controller (DC)** | A server holding a writable copy of the domain's directory, handling authentication |
| **Forest** | One or more domains sharing a common schema and trust — the top-level AD boundary |
| **Tree** | A set of domains in a forest sharing a contiguous DNS namespace |
| **Organizational Unit (OU)** | A folder-like container for organizing users/computers/groups, the unit Group Policy targets |
| **Users / Groups / Computers** | Core object types stored in the directory |
| **Group Policy (GPO)** | Centrally pushed configuration/security settings applied to OUs |

```mermaid
flowchart TD
    Forest --> Tree --> Domain
    Domain --> DC[Domain Controller]
    Domain --> OU1[OU: Finance]
    Domain --> OU2[OU: IT]
    OU1 --> U1[Users]
    OU1 --> C1[Computers]
    OU2 --> U2[Users]
    OU2 --> C2[Computers]
    DC -->|Kerberos/LDAP auth| U1
    DC -->|Kerberos/LDAP auth| U2
```

## Kerberos & LDAP — The Two Protocols That Matter Most

- **Kerberos**: the authentication protocol. A user proves identity once to get a Ticket Granting Ticket (TGT), then uses it to request service tickets for specific resources — no repeated password transmission. This is the protocol behind Kerberoasting and AS-REP roasting (Module 11).
- **LDAP**: the query protocol used to *read* directory data — users, groups, OU structure. This is what PowerShell's `Get-AD*` cmdlets and raw `[ADSI]` queries speak under the hood.

## DNS in AD

AD is DNS-dependent: domain controllers register themselves as DNS SRV records so clients can locate them. A misconfigured or poisoned internal DNS is a direct attack path into AD discovery.

## Authentication vs Authorization

- **Authentication**: proving who you are (Kerberos ticket, NTLM hash)
- **Authorization**: what you're allowed to do once authenticated (group membership, ACLs, GPO-applied rights)

## Trust Relationships

A trust lets users in one domain/forest authenticate to resources in another. Trusts can be one-way or two-way, and understanding trust *direction* matters for lateral movement planning (covered further in Module 11).

## Service Accounts & Privileged Accounts

- **Service accounts** run applications/services under a dedicated AD identity — frequently over-privileged and rarely rotated, making them high-value targets (Kerberoasting target pool).
- **Domain Admins** and other privileged groups hold forest-wide control — the ultimate target in most AD assessments.

## How Endpoints Relate to AD

A domain-joined Windows machine trusts its DC for authentication, receives GPO-pushed configuration on boot/logon, and its local `Administrators` group typically includes the `Domain Admins` group by default — meaning a Domain Admin can log into any joined machine as a local admin.

## Lab Exercise

1. On a lab DC, run `Get-ADDomain` and `Get-ADForest` and map the output fields to the concepts above.
2. Identify the domain's DNS SRV records for the DC using `nslookup -type=SRV _ldap._tcp.dc._msdcs.<domain>`.
3. Diagram your own lab's forest/domain/OU structure.

## Knowledge Check

1. What's the practical difference between what Kerberos does and what LDAP does?
2. Why does a misconfigured internal DNS matter to AD security?
3. Why are service accounts frequently flagged as higher-risk than regular user accounts?