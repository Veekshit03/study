# Module 04 — PowerShell for Windows Administration (1)

## Status: 🟢 Complete

## Core Administration Cmdlets

| Cmdlet | Purpose | CMD equivalent | Notes |
| --- | --- | --- | --- |
| `Get-ComputerInfo` | Full OS/hardware/BIOS summary | `systeminfo` | Richer object output, filterable |
| `Get-CimInstance` | Modern WMI query interface | `wmic` | Replaces legacy `Get-WmiObject` |
| `Get-WmiObject` | Legacy WMI query | `wmic` | Deprecated in PS7+; still works in 5.1 |
| `Get-Process` | Running processes | `tasklist` | Object output, includes handles/modules |
| `Get-Service` | Installed services + state | `sc query` | Pipeable, filterable by status |
| `Get-NetIPAddress` | IP config per interface | `ipconfig` | Structured, scriptable |
| `Get-NetTCPConnection` | Active TCP connections | `netstat -ano` | Includes owning process ID directly |
| `Get-NetRoute` | Routing table | `route print` | Object form |
| `Get-NetAdapter` | NIC inventory + status | `ipconfig /all` (partial) | Shows link speed, MAC, driver |
| `Get-LocalUser` | Local user accounts | `net user` | Includes enabled/disabled, last logon |
| `Get-LocalGroup` | Local groups | `net localgroup` | — |
| `Get-LocalGroupMember` | Group membership | `net localgroup <grp>` | Resolves SIDs to names |
| `Get-ChildItem` | List files/dirs (any provider) | `dir` | Works on registry/cert store too |
| `Get-Content` | Read file contents | `type` | Supports `-Tail`, `-Wait` (like `tail -f`) |
| `Get-Item` | Get single file/registry object | `dir <single>` | Returns one object, not a listing |
| `Get-Command` | Discover available cmdlets | `help` (partial) | Searchable by verb/noun/module |
| `Get-Help` | Full documentation | `/?` | `-Examples`, `-Full`, `-Online` |
| `Get-Module` | Loaded/available modules | n/a | `-ListAvailable` shows all installed |
| `Get-ExecutionPolicy` | Current script execution policy | n/a | Covered in depth in Module 08 |
| `Get-ScheduledTask` | Scheduled tasks | `schtasks /query` | Object form, pipeable to filter by state |
| `Get-WinEvent` | Event log querying | `wevtutil` | Powers Modules 15–16 |

## Practical Demonstration

```powershell
Get-CimInstance Win32_OperatingSystem | Select-Object Caption, Version, OSArchitecture, LastBootUpTime
Get-NetTCPConnection -State Listen | Select-Object LocalAddress, LocalPort, OwningProcess
Get-ScheduledTask | Where-Object { $_.State -eq 'Ready' } | Select-Object TaskName, TaskPath
```

Each of these replaces a multi-step CMD/`wmic` workflow with one readable, filterable line — the pattern this whole course leans on.

## Interpreting Output: Why It Matters

- `Get-NetTCPConnection -State Listen` directly shows which process ID owns each listening port — no manual `netstat`+`tasklist` cross-referencing needed.
- `Get-ScheduledTask` combined with `Get-ScheduledTaskInfo` reveals last-run time and result code — useful for spotting persistence mechanisms (Module 07) or legitimate automation.

## Lab Exercise

1. Use `Get-CimInstance Win32_Product` to list installed software (note: can be slow/noisy — explain why in your answer).
2. Compare `Get-Process | measure` object count against `tasklist | find /c /v ""` in CMD.
3. Find all scheduled tasks that run as SYSTEM: `Get-ScheduledTask | Where-Object { $_.Principal.UserId -eq 'SYSTEM' }`.

## Knowledge Check

1. Why is `Get-CimInstance` generally preferred over `Get-WmiObject` today?
2. What extra field does `Get-NetTCPConnection` give you that raw `netstat -ano` output requires manual correlation to get?
3. Name two things `Get-LocalUser` tells you that `net user` doesn't show as cleanly.