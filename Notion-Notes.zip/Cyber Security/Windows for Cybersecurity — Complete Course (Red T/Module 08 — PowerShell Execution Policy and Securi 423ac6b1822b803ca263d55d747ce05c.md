# Module 08 — PowerShell Execution Policy and Security Controls (1)

## Status: 🟢 Complete

## What Is Execution Policy, and Why

PowerShell's Execution Policy controls whether `.ps1` scripts are allowed to run on a given machine. Microsoft added it to prevent *accidental* script execution (e.g. a user double-clicking a malicious `.ps1` from email) — **not** to stop a determined attacker.

## Policy Levels

| Policy | Behavior |
| --- | --- |
| `Restricted` | No scripts run at all (default on client Windows) |
| `AllSigned` | Only digitally signed scripts run |
| `RemoteSigned` | Local scripts run freely; downloaded scripts need a signature |
| `Unrestricted` | All scripts run, warns on downloaded ones |
| `Bypass` | Nothing blocked, no warnings |
| `Undefined` | No policy set at this scope; falls through to the next scope |

## Scope & Precedence

Policies apply at four scopes, checked in this order (most specific wins):

1. **Process** — this PowerShell session only
2. **CurrentUser** — this user's registry setting
3. **LocalMachine** — machine-wide default
4. **Group Policy** — enforced via GPO, overrides all of the above

```powershell
Get-ExecutionPolicy -List   # shows all four scopes at once
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
```

## "Bypass" Techniques — What They Actually Do

| Technique | What happens |
| --- | --- |
| `powershell.exe -ExecutionPolicy Bypass -File script.ps1` | Sets Process-scope policy for this launch only — doesn't touch CurrentUser/LocalMachine |
| `powershell.exe -NoProfile` | Skips loading profile scripts — speeds startup, avoids profile-based restrictions |
| `powershell.exe -Command "..."` | Runs an inline command string, no `.ps1` file, so no file-based policy check applies |
| `-EncodedCommand <Base64>` | Passes a Base64-encoded command — avoids quoting issues, **also a common detection signature** |
| Execution via `cmd.exe` calling `powershell -enc ...` | Chains shells — same execution, different parent process in logs |
| Alternative hosts (e.g. custom .NET host loading `System.Management.Automation`) | Runs PowerShell engine code without invoking `powershell.exe` at all |

## Critical Point: This Is Not a Security Boundary

Microsoft's own documentation states Execution Policy is a **safety feature**, not a **security control**. It does nothing to stop:

- Antivirus/Defender signature or behavioral detection
- AMSI (Antimalware Scan Interface) scanning script content at runtime
- AppLocker or WDAC application control policies
- A user manually pasting commands into an interactive prompt (no file, no policy check at all)

Presenting "bypassing Execution Policy" as equivalent to "bypassing security" is a common and important misconception to correct with students.

## Detection: What to Log and Watch

| Signal | Source |
| --- | --- |
| `-EncodedCommand` usage | Script Block Logging (Event ID 4104) |
| `-ExecutionPolicy Bypass` on command line | Process creation (Event ID 4688) with command-line auditing enabled |
| PowerShell spawned from unusual parent (e.g. Office apps) | Sysmon Event ID 1 |
| Policy changed via `Set-ExecutionPolicy` | Registry/Group Policy audit |

```mermaid
flowchart TD
    A[User/script runs PowerShell] --> B{Execution Policy check}
    B -->|Blocks .ps1 files| C[Script won't run as a file]
    B -->|Does NOT block| D[Inline commands]
    B -->|Does NOT block| E[AMSI/Defender/AppLocker]
    C -.bypassed via -ExecutionPolicy Bypass.-> F[File still just a safety-net skip]
    D --> G[Real security relies on D/E, not policy]
    E --> G
```

## Lab Exercise (safe, harmless scripts only)

1. Set Process-scope policy to `Bypass`, run a harmless `.ps1` that prints `Hello`, then open a new session and confirm the policy reverted to the LocalMachine default.
2. Run the same script via `-EncodedCommand` and capture the Script Block Logging event it generates (Event ID 4104) in Event Viewer.
3. Compare command-line visibility in Event ID 4688 for a plain invocation vs an `-EncodedCommand` invocation.

## Knowledge Check

1. Why is Execution Policy described as a "safety feature" rather than a security boundary?
2. What's the real risk-reduction benefit of `-EncodedCommand` for detection purposes — to the defender, not the attacker?
3. Name two controls that stay fully in effect even when Execution Policy is set to `Bypass`.