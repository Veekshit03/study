# Module 12 — Post-Enumeration Methodology (1)

## Status: 🟢 Complete

## Where Post-Enumeration Fits

```mermaid
flowchart LR
    A[Reconnaissance] --> B[Enumeration]
    B --> C[Post-Enumeration / Vulnerability Assessment]
    C --> D[Exploitation Validation]
    D --> E[Post-Exploitation]
```

- **Reconnaissance**: passive/broad info gathering before touching the target meaningfully.
- **Enumeration**: active, detailed collection (Modules 06, 10 of this course).
- **Post-enumeration / vulnerability assessment**: *this module* — making sense of what was collected.
- **Exploitation validation**: confirming a suspected weakness is actually exploitable (handled carefully, in scope, in lab).
- **Post-exploitation**: what happens after access is gained — outside this module's scope.

## Consolidating Findings

Bring together: host profile (Module 06), privesc vectors (Module 07), AD structure and risk (Modules 10–11) into one working document per target/domain. Structure it by:

1. Attack surface (exposed services, reachable hosts)
2. Privileged users & sensitive systems
3. Misconfigurations found (service perms, ACLs, delegation, GPO)
4. Policy weaknesses (password policy, lack of LAPS)
5. Trust relationships and lateral movement paths

## Prioritizing Findings

Not every finding carries equal weight. A simple priority model:

| Priority | Criteria |
| --- | --- |
| Critical | Directly leads to Domain Admin / SYSTEM with no further steps |
| High | Requires one additional step (e.g. cracking a Kerberoasted hash) |
| Medium | Weakness present but conditions for abuse are unclear/limited |
| Low | Hygiene issue, no direct path to privilege demonstrated |

## Documentation & Reporting Essentials

Every finding should record: what was found, how it was found (command/technique), evidence (sanitized screenshot or output), risk rating, and a specific remediation — vague recommendations ("improve security") are not actionable for a client or team.

## Post-Enumeration Checklist — Standalone Windows Host

- [ ]  OS/patch level documented
- [ ]  Local admin group membership reviewed
- [ ]  Services/scheduled tasks checked for writable binaries/paths
- [ ]  Registry autoruns reviewed
- [ ]  AV/firewall status confirmed
- [ ]  Shares reviewed for excessive permissions

## Post-Enumeration Checklist — Active Directory

- [ ]  Domain/forest structure mapped
- [ ]  Privileged group membership reviewed (nested groups included)
- [ ]  SPN accounts cross-referenced against privilege
- [ ]  Preauth-disabled accounts identified
- [ ]  Delegation configurations reviewed
- [ ]  Password policy and LAPS presence checked
- [ ]  SYSVOL/GPO scripts reviewed for embedded credentials
- [ ]  Trust relationships mapped and risk-rated

## Lab Exercise

1. Using your Module 06/07/10/11 lab findings, produce one consolidated report using the checklist above.
2. Rate each finding Critical/High/Medium/Low with justification.
3. Write one specific, actionable remediation per finding (not generic advice).

## Knowledge Check

1. Where does "post-enumeration" sit between enumeration and exploitation?
2. Why does finding priority matter more than finding count in a report?
3. Name two things a good remediation note must include beyond "fix this."