# Module 18 — PowerShell Security, Evasion and Detection Engineering (1)

## Status: 🟢 Complete

## Obfuscation & Encoded Commands

Attackers obfuscate scripts (string concatenation, Base64, char-code arrays) to evade naive string-matching detection. Defenders counter this with Script Block Logging (Module 15), which captures the *de-obfuscated* content at execution time regardless of how it was encoded.

## AMSI (Antimalware Scan Interface)

AMSI lets PowerShell hand script content to the registered antivirus engine *at runtime*, including content assembled dynamically (e.g. built in memory, never written to disk). This is why disk-based file scanning alone is insufficient, and why AMSI is one of the most important modern PowerShell defenses — and a frequent target of bypass attempts.

## Constrained Language Mode (CLM)

CLM restricts PowerShell to a safe subset of the language — blocking direct .NET method calls, COM object creation, and other primitives commonly used in advanced attack tooling. Typically enforced via WDAC/AppLocker policy alongside Full Language Mode for trusted admins.

## Application Control: AppLocker & WDAC

| Control | Approach |
| --- | --- |
| AppLocker | Rule-based allow/deny by path, publisher, or hash |
| WDAC (Windows Defender Application Control) | Stronger, kernel-enforced allowlisting, harder to bypass than AppLocker |

Both can restrict which scripts/binaries run at all — a layer Execution Policy (Module 08) explicitly does not provide.

## Attack Surface Reduction & Defender Detection

ASR rules block specific risky behaviors (e.g. Office apps spawning child processes, obfuscated script execution) at a granular level, complementing signature and behavioral detection.

## Living-off-the-Land Binaries (LOLBins)

Legitimate, signed Windows binaries (`certutil.exe`, `mshta.exe`, `regsvr32.exe`) can be abused for download, execution, or bypass purposes — detection must focus on *unusual usage patterns* of trusted binaries, not just "is this binary bad" (it isn't, inherently).

## Detection Engineering with Sigma Rules

Sigma is a generic, vendor-agnostic rule format for writing detection logic that can be converted to SIEM-specific query languages.

```yaml
title: Suspicious Encoded PowerShell Command
logsource:
  product: windows
  service: powershell
detection:
  selection:
    EventID: 4104
    Message|contains: 'FromBase64String'
  condition: selection
level: high
```

## Sysmon-Based Investigation

Sysmon Event ID 1 (process creation with full command line and parent process), Event ID 3 (network connection), and Event ID 11 (file creation) together give far richer telemetry than built-in Windows logging alone — the backbone of most mature detection engineering programs.

```mermaid
flowchart TD
    A[Attacker technique] --> B{Detection layer}
    B --> C[AMSI: runtime script content scan]
    B --> D[AppLocker/WDAC: what's allowed to run]
    B --> E[ASR rules: block risky behavior patterns]
    B --> F[Sysmon + Sigma: behavioral detection/correlation]
    C & D & E & F --> G[Layered defense — no single control is sufficient alone]
```

## Lab Exercise

1. Enable Constrained Language Mode in a lab VM and observe which legitimate script operations now fail.
2. Write a Sigma rule detecting any process creation where `powershell.exe` is the child of `winword.exe` or `excel.exe`.
3. Review Sysmon Event ID 1 logs for one lab exercise from Module 16 and identify the exact detection fields that would have triggered your rule.

## Knowledge Check

1. Why does AMSI matter even for scripts that are never written to disk?
2. What's the key practical difference in strength between AppLocker and WDAC?
3. Why is "is this binary bad" the wrong question to ask about LOLBins?