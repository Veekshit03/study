# Module 11 — Active Directory Security Assessment (1)

## Status: 🟢 Complete

This module takes raw enumeration data from Module 10 and asks: which of these findings are actual risk, and which are just conditions worth noting?

## Excessive Privileges & Stale Accounts

| Finding | Enumeration | Risk if true |
| --- | --- | --- |
| Users in Domain Admins beyond core IT staff | `Get-ADGroupMember "Domain Admins"` | Excess blast radius if any one account is compromised |
| Stale accounts (old `pwdlastset`, long-inactive) | `Get-ADUser -Filter * -Properties pwdlastset,lastlogondate` | Forgotten credentials, weaker monitoring |
| Unnecessary privileged service accounts | Cross-reference `servicePrincipalName` against privileged group membership | Kerberoastable + highly privileged = severe |

## Weak Password Policy & Spraying Risk

`Get-ADDefaultDomainPasswordPolicy` — a short minimum length or no lockout threshold materially increases password-spraying success likelihood. This is a *condition*, not proof of compromise — note it as risk, not as an exploited finding.

## Delegation Types — What Each Actually Allows

| Type | Mechanism | Risk |
| --- | --- | --- |
| **Unconstrained delegation** | Host can cache and reuse *any* user's TGT that authenticates to it | Compromising that host can lead to capturing high-privilege tickets |
| **Constrained delegation** | Host can impersonate users only to specific listed services (`msDS-AllowedToDelegateTo`) | Narrower, but still a path if those services are sensitive |
| **Resource-based constrained delegation (RBCD)** | The *resource* defines who can delegate to it (`msDS-AllowedToActOnBehalfOfOtherIdentity`) | Can be abused if an attacker can write that attribute |

## Kerberoasting & AS-REP Roasting — Concepts

- **Kerberoasting**: any authenticated user can request a service ticket for any SPN-bearing account; that ticket is encrypted with the service account's password hash and can be taken offline for cracking. Weak service-account passwords are the actual risk, not the request itself (which is normal Kerberos behavior).
- **AS-REP Roasting**: accounts with "Do not require Kerberos preauthentication" set can have their AS-REP response captured and cracked offline without ever authenticating as that user.

## LAPS / Windows LAPS

Local Administrator Password Solution randomizes and centrally stores local admin passwords per machine, preventing one cracked local admin hash from granting lateral movement across every machine that shares it. Its *absence* is itself a finding.

## SYSVOL / NETLOGON & GPO Exposure

Legacy Group Policy Preferences could embed a `cpassword` (weakly "encrypted," trivially reversible) — any domain user can read SYSVOL, so a leftover GPP password is a direct credential disclosure. Also review GPOs for scripts containing hardcoded credentials.

## Dangerous ACLs & Trust Risk

Overly permissive ACLs (e.g. a low-privileged group with `GenericAll`/`WriteDACL` on a privileged object) can allow privilege escalation entirely through directory permissions, no exploit needed. Trust direction determines whether a compromised domain can reach another.

```mermaid
flowchart TD
    A[AD Enumeration data] --> B{Weakness category}
    B --> C[Privilege/stale accounts]
    B --> D[Delegation misconfig]
    B --> E[Kerberoast/AS-REP candidates]
    B --> F[GPO/SYSVOL exposure]
    B --> G[Dangerous ACLs]
    C & D & E & F & G --> H[Risk assessment: identified ≠ proven exploitable]
    H --> I[Controlled lab validation only]
```

## Lab Exercise

1. In a lab domain, identify every SPN-bearing account and classify whether it's also in a privileged group.
2. Check `Get-ADDefaultDomainPasswordPolicy` and assess whether the minimum length / lockout threshold is adequate.
3. Search a lab SYSVOL share for any legacy `Groups.xml` containing a `cpassword` attribute.

## Knowledge Check

1. Why is requesting a Kerberoastable ticket "normal" protocol behavior rather than an exploit in itself?
2. What's the practical difference between constrained and resource-based constrained delegation?
3. Why does the absence of LAPS matter even if no password reuse has been proven yet?