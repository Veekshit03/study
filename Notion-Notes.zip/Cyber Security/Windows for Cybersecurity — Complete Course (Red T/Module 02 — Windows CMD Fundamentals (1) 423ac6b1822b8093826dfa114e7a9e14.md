# Module 02 — Windows CMD Fundamentals (1)

## Status: 🟢 Complete

## Normal vs Administrator CMD

Right-click → "Run as administrator" launches `cmd.exe` with an elevated token (UAC-approved). Many enumeration and config commands silently fail or show partial data without elevation — always note which context a command needs.

## Command Syntax & Internal vs External Commands

- **Internal commands** (`dir`, `cd`, `echo`, `set`) are built into `cmd.exe` itself — no file on disk.
- **External commands** (`ipconfig.exe`, `tasklist.exe`) are separate executables found via `%PATH%`.
- `help` or `<command> /?` shows built-in usage for most commands.

## Core Command Reference

| Command | Purpose | Key switches | Offensive use | Defensive use |
| --- | --- | --- | --- | --- |
| `dir` | List directory contents | `/a` (all incl. hidden), `/s` (recursive) | Find sensitive/config files | Audit file sprawl |
| `cd` | Change directory | `..` (up), `\` (root) | Navigate target filesystem | — |
| `copy` / `xcopy` / `robocopy` | Copy files | `/s`, `/e` (recursive) | Stage/exfil files | Backup verification |
| `del` | Delete file | `/f` (force), `/q` (quiet) | Clean up artifacts (lab only) | — |
| `findstr` | Search text in files | `/s /i "pattern"` | Hunt for creds in config files | Search logs for IOCs |
| `tasklist` | List running processes | `/v` (verbose), `/svc` (show hosting services) | ID security tooling/AV running | Spot unknown processes |
| `taskkill` | Terminate a process | `/PID <n>` /`/F` (force) | Stop monitoring tool (lab only) | Kill malicious process |
| `sc query` | List/query services | `state= all` | Enumerate service attack surface | Baseline services |
| `net start` / `net stop` | Start/stop a service | — | Control service state | Incident containment |
| `ipconfig` | Network config | `/all` | Recon | Baseline network config |
| `systeminfo` | Full system/OS detail | — | Patch-level & OS fingerprinting | Asset inventory |
| `set` | Show/set environment variables | — | Spot sensitive env vars | — |

## Expected Output & Interpretation (example: `tasklist /svc`)

```
Image Name     PID  Services
svchost.exe    904  Dnscache,LanmanWorkstation
notepad.exe   4012  N/A
```

A security analyst reads this for: unexpected `svchost.exe` children, processes with no legitimate service tie, or unusually high PID counts for a single binary name (possible process injection/masquerading).

## I/O Redirection, Pipes, Chaining

| Operator | Meaning |
| --- | --- |
| `>` | Redirect output to file (overwrite) |
| `>>` | Append output to file |
| `<` | Redirect input from file |
| `|` | Pipe output of one command into another |
| `&` | Run commands sequentially |
| `&&` | Run next only if previous succeeded |
| `||` | Run next only if previous failed |

Example: `tasklist > procs.txt && findstr /i "powershell" procs.txt` — list processes, save to file, then search just for PowerShell instances.

## Batch Scripting Fundamentals

```bash
@echo off
set TARGET=192.168.1.10
echo Pinging %TARGET%...
ping -n 2 %TARGET%
if %errorlevel%==0 (
    echo Host is up
) else (
    echo Host is down
)
```

`@echo off` suppresses command echoing; `%errorlevel%` holds the exit code of the last command — the basis of batch-file conditional logic.

## Practical Scenario

A penetration tester with a low-privilege CMD shell needs a fast picture of running security tooling before deciding next steps. `tasklist /svc` plus `findstr /i "defender sense mcafee crowdstrike"` quickly flags EDR/AV presence without needing PowerShell.

## Lab Exercise

1. Use `dir /s /a` to find all `.config` or `.txt` files under `C:\inetpub` (or a lab-created equivalent) in under 2 minutes.
2. Write a batch script that pings a target, logs the result to a file, and prints "UP"/"DOWN" based on `%errorlevel%`.
3. Use `tasklist /svc > out.txt` then `findstr` to isolate `svchost.exe` entries.

## Knowledge Check

1. Difference between an internal and external CMD command?
2. What does `&&` do differently from `&`?
3. Why would `tasklist /svc` matter more to an attacker than plain `tasklist`?
4. What does `%errorlevel%` represent in a batch script?