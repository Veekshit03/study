# Module 13 — PowerShell Scripting for Cybersecurity (1)

## Status: 🟢 Complete

## Script Structure & .ps1 Files

A PowerShell script is a plain text file of cmdlets saved with a `.ps1` extension. It runs top to bottom unless organized into functions.

```powershell
<#
.SYNOPSIS
  Collects basic host info for a security assessment.
#>
param(
    [string]$ComputerName = $env:COMPUTERNAME
)

function Get-HostSummary {
    param([string]$Name)
    [PSCustomObject]@{
        ComputerName = $Name
        OS           = (Get-CimInstance Win32_OperatingSystem).Caption
        Uptime       = (Get-Date) - (Get-CimInstance Win32_OperatingSystem).LastBootUpTime
    }
}

Get-HostSummary -Name $ComputerName
```

**Line-by-line:** the comment-based help block (`<# ... #>`) documents the script's purpose; `param()` declares script-level input with a sensible default; the function encapsulates reusable logic and returns a structured `PSCustomObject` rather than raw text, so the result can be piped further.

## Variables, Parameters, Input/Output

- `param()` blocks define typed, optional/mandatory, and defaulted inputs.
- `Write-Output` emits pipeline data; `Write-Host` prints to console only (not pipeable) — use `Write-Output`/`return` for data, `Write-Host`/`Write-Verbose` for status messages.

## Conditionals, Loops, Arrays, Hashtables (Applied)

```powershell
$targets = @("10.0.0.5", "10.0.0.6")
foreach ($t in $targets) {
    if (Test-Connection $t -Count 1 -Quiet) {
        Write-Output "$t is up"
    } else {
        Write-Output "$t is down"
    }
}
```

## Error Handling & Logging

```powershell
function Invoke-SafeQuery {
    param([string]$Path)
    try {
        Get-Item -Path $Path -ErrorAction Stop
    } catch {
        Add-Content -Path "errors.log" -Value "$(Get-Date): $_"
        Write-Warning "Logged failure for $Path"
    }
}
```

Logging failures to a file rather than just the console preserves evidence for later review — a habit worth building into every script from the start.

## Modules & Reusable Functions

Group related functions into a `.psm1` module file and `Import-Module` it, rather than copy-pasting functions between scripts — this is the foundation Module 14's automation library builds on.

## Script Debugging & Input Validation

```powershell
param(
    [Parameter(Mandatory)]
    [ValidateScript({ Test-Path $_ })]
    [string]$LogPath
)
```

`ValidateScript` rejects bad input before the script body even runs — far safer than discovering a bad path mid-execution. `Set-PSDebug -Trace 1` or breakpoints in the ISE/VS Code debugger step through execution line by line.

## Lab Exercise

1. Write a script with a `param()` block, a function, and a `try/catch` block that logs failures to a file.
2. Add `ValidateScript` input validation to one parameter.
3. Convert two related functions into a `.psm1` module and import it into a separate script.

## Knowledge Check

1. Why prefer `Write-Output`/`return` over `Write-Host` for data a script produces?
2. What does wrapping file access in `try/catch` with logging give you that a bare command doesn't?
3. Why move reusable functions into a module instead of duplicating them per script?