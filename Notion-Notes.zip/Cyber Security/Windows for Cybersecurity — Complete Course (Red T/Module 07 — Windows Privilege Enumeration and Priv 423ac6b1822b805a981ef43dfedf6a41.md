# Module 07 — Windows Privilege Enumeration and Privilege Escalation Concepts (1)

## Status: 🟡 In progress — core content drafted

Goal: find misconfigurations that let a low-privilege user become admin or SYSTEM.

## Identity & Rights

### CMD

| Command | Purpose |
| --- | --- |
| `whoami` | Current user |
| `whoami /priv` | Token privileges — watch for `SeImpersonatePrivilege`, `SeAssignPrimaryTokenPrivilege`, `SeDebugPrivilege`, `SeBackupPrivilege` |
| `whoami /groups` | Group membership + SIDs; check for high-priv groups |
| `whoami /all` | Combination of the above |

### PowerShell

| Command | Purpose |
| --- | --- |
| `[Security.Principal.WindowsIdentity]::GetCurrent()` | Same identity info as an object |
| `Get-LocalGroupMember Administrators` | Who is local admin |
| `Get-LocalUser` / `Get-LocalGroup` | Enumerate local accounts/groups |

## Service Misconfiguration

- `sc query` (CMD) / `Get-Service` (PS) — list services
- `sc qc <svc>` — service config, inspect binary path
- `icacls "C:\Program Files\App\svc.exe"` — writable binary = replace and escalate on service restart
- Unquoted service path: `wmic service get name,pathname,startmode` (CMD) or `Get-CimInstance Win32_Service | Where-Object { $_.PathName -notlike '"*' -and $_.PathName -like '* *' }` (PS) — a space in an unquoted path is a hijack opportunity
- `Get-Acl 'HKLM:\SYSTEM\CurrentControlSet\Services\<svc>'` — weak ACL lets a low-priv user reconfigure the service

## Scheduled Tasks

- `schtasks /query /fo LIST /v` (CMD) / `Get-ScheduledTask` (PS) — find SYSTEM-run tasks whose target script/binary is writable

## Registry & Autoruns

- `reg query "HKLM\...\Run"` — autorun entries; a writable target = persistence/privesc
- AlwaysInstallElevated: `reg query HKLM\SOFTWARE\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated` and the same under `HKCU` — both set to 1 means any MSI installs run as SYSTEM

## Token / Impersonation Concepts

If a process holds `SeImpersonatePrivilege` and an attacker can coerce a SYSTEM-authenticated connection (e.g. via the print spooler or named-pipe tricks), the token can be captured for full SYSTEM access. This course covers the concept, recognition, and detection — not a live exploit chain.

## File & Directory Permissions

- `icacls <path>` — writable directories in `PATH`, startup folders
- `Get-Acl <path> | fl` (PS) — object form of the same check

## Patch / AV / Firewall Status

- `wmic qfe list` / `Get-HotFix` — missing patches
- `Get-MpComputerStatus` — Defender status
- `netsh advfirewall show allprofiles` — firewall state

```mermaid
flowchart TD
    A[Low-priv shell] --> B[Enumerate tokens/privileges]
    A --> C[Enumerate services & ACLs]
    A --> D[Enumerate scheduled tasks]
    A --> E[Enumerate registry autoruns]
    B & C & D & E --> F{Writable / misconfigured path found?}
    F -->|Yes| G[Controlled lab escalation]
    F -->|No| H[Document findings, move to next vector]
```

## Lab Exercises

*To be added — isolated lab VM with intentionally misconfigured service + unquoted path.*

## Knowledge Check

*To be added.*