# Module 01 — Introduction to Windows Command-Line Environments (1)

## Status: 🟢 Complete

## What is a Command-Line Interface?

A CLI lets you control a computer by typing text commands instead of clicking icons (GUI). Every command you type is parsed, matched to a program or built-in handler, executed, and its result is printed back as text (CMD) or as structured objects (PowerShell).

**Why it matters in security:** almost every exploitation, enumeration, and administration task on Windows ultimately runs through CMD or PowerShell — GUIs hide detail that a CLI exposes directly.

## What is a Shell?

A shell is the program that reads your commands and hands them to the OS. Windows ships two:

| Shell | Executable | Nature |
| --- | --- | --- |
| Command Prompt | `cmd.exe` | Legacy, text-only, DOS-derived |
| PowerShell | `powershell.exe` (5.1, built-in) / `pwsh.exe` (7.x, cross-platform) | Modern, object-oriented, .NET-based |

## CMD vs PowerShell

| Aspect | CMD | PowerShell |
| --- | --- | --- |
| Output | Plain text | .NET objects (can be filtered/sorted/reused) |
| Scripting | Batch (.bat/.cmd) — limited | Full scripting language (.ps1) |
| Extensibility | Few built-ins | Thousands of cmdlets + modules |
| Security tooling | Minimal | Native AD/network/security cmdlets |
| Logging | Basic | Script Block Logging, Transcription, AMSI integration |

PowerShell 5.1 ships with Windows; PowerShell 7.x is a separate, cross-platform install (`pwsh.exe`) with more performance and parallelism features but fewer built-in Windows-only modules unless compatibility shims are loaded.

## Windows Terminal

A modern host application that can run CMD, PowerShell 5.1, and PowerShell 7 side by side in tabs — doesn't change what the shells do, just how you access them.

## How a Command Executes (Process Basics)

```mermaid
flowchart LR
    A[User types command] --> B[Shell parses it]
    B --> C{Built-in or external?}
    C -->|Built-in| D[Shell handles internally]
    C -->|External| E[Shell searches PATH]
    E --> F[Windows creates a process]
    D --> G[Result printed]
    F --> G
```

Every external command becomes a new **process** — a running instance of a program with its own memory space, handle to parent, and security token (inherited from the user who launched it). This token is what later modules (07, 10) revisit for privilege assessment.

## Environment Variables, Working Directory, Paths

- Environment variables (`%PATH%` in CMD, `$env:PATH` in PowerShell) tell the shell where to look for executables and hold session config (`%USERPROFILE%`, `%TEMP%`).
- The **working directory** is where relative paths resolve from — critical for both scripting and exploit staging.
- File permissions (NTFS ACLs) gate who can read/write/execute a path — foundational for the privilege-escalation checks in Module 07.

## Practical Demonstration: CMD vs PowerShell Side by Side

| Task | CMD | PowerShell |
| --- | --- | --- |
| Show current directory | `cd` | `Get-Location` / `pwd` |
| List files | `dir` | `Get-ChildItem` / `ls` |
| Show env variable | `echo %PATH%` | `$env:PATH` |
| Show current user | `whoami` | `whoami` (same binary call) or `$env:USERNAME` |

Open both shells on a lab VM and run each pair — note CMD returns plain strings, PowerShell returns objects you can pipe further (e.g. `Get-ChildItem | Sort-Object Length`).

## Lab Exercise

1. Open CMD and PowerShell side by side in Windows Terminal.
2. Run `dir` and `Get-ChildItem` in the same folder — compare raw output.
3. Pipe the PowerShell result into `Select-Object Name, Length` and observe the object-based formatting CMD cannot replicate.
4. Check `$PSVersionTable` to confirm whether you're in PowerShell 5.1 or 7.x.

## Knowledge Check

1. What fundamentally differs between CMD's output and PowerShell's output?
2. Why would a security tool prefer parsing PowerShell object output over CMD text output?
3. What security-relevant object is created every time an external command runs?
4. Name one practical reason a penetration tester checks `$PSVersionTable` early in an engagement.