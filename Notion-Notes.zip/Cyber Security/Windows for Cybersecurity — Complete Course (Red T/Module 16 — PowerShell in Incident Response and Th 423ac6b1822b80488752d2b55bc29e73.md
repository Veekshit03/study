# Module 16 — PowerShell in Incident Response and Threat Hunting (1)

## Status: 🟢 Complete

Each scenario below follows: alert/incident → investigation objective → commands → expected evidence → interpretation → conclusion → containment → remediation.

## Scenario 1 — Suspicious PowerShell Execution Alert

- **Alert**: EDR flags `powershell.exe -enc <base64>` launched by `winword.exe`.
- **Objective**: determine what the script did and whether it executed successfully.
- **Commands**: `Get-WinEvent` filtered to Event ID 4104 around the alert timestamp; check Sysmon Event ID 1 for the parent-child relationship; check Event ID 3 for any outbound connection from the resulting process.
- **Expected evidence**: decoded script content, destination IP/domain if it attempted a download.
- **Interpretation**: Office spawning PowerShell with an encoded command is a classic macro-dropper pattern.
- **Conclusion**: likely malicious unless explained by known, approved automation.
- **Containment**: isolate host, suspend the user's active sessions.
- **Remediation**: block the destination indicator, patch/disable macros from untrusted sources, review Office macro security policy.

## Scenario 2 — Unusual User Activity

- **Alert**: logon from a service account at an unusual hour.
- **Objective**: confirm whether this is legitimate automation or compromised credential use.
- **Commands**: `Get-WinEvent` for Event ID 4624 (logon type field matters — interactive vs network vs service), cross-reference with that account's normal scheduled task/service usage.
- **Conclusion**: a service account logging on interactively (type 2) rather than as a service (type 5) is a strong anomaly signal.

## Scenario 3 — Persistence Investigation

- **Alert**: new scheduled task created on a server.
- **Commands**: Event ID 4698 for task creation detail, `Get-ScheduledTask` for current state, inspect the task's action (what it runs, as which account).
- **Interpretation**: a SYSTEM-run task pointing to a script in a user-writable path is a persistence red flag regardless of how it was alerted.

## Scenario 4 — Network Connection Investigation

- **Alert**: Sysmon Event ID 3 shows an unexpected outbound connection from `svchost.exe`.
- **Commands**: `Get-NetTCPConnection` to confirm the connection is still active, correlate PID to the exact `svchost.exe` service hosting it (`tasklist /svc`), check whether that service should make external connections at all.

## Scenario 5 — Malware Triage / IOC Searching

- **Objective**: sweep the estate for a known-bad file hash or IP.
- **Commands**:

```powershell
Get-FileHash C:\suspect\file.exe -Algorithm SHA256
Get-WinEvent -LogName Sysmon -FilterXPath "*[System[(EventID=3)]] and *[EventData[Data='203.0.113.5']]"
```

- **Evidence**: matching hash/IP across hosts builds a timeline of spread.

## Timeline Creation & Evidence Preservation

Build timelines by correlating Security log, PowerShell Operational log, and Sysmon timestamps into one ordered table (TimeCreated, EventID, Host, Summary). Preserve raw `.evtx` exports (`wevtutil epl`) before any remediation that might roll logs over.

```mermaid
flowchart LR
    A[Alert triggers] --> B[Pull relevant event IDs]
    B --> C[Correlate across logs/hosts]
    C --> D[Build timeline]
    D --> E[Conclusion + containment]
    E --> F[Remediation + lessons learned]
```

## Lab Exercise

1. Simulate Scenario 1 in a lab VM (harmless encoded command from a script, not Word) and build the full investigation writeup.
2. Export the relevant Security and PowerShell Operational logs as `.evtx` before concluding the exercise.
3. Produce one timeline table correlating at least three event sources.

## Knowledge Check

1. Why does logon *type* matter more than the logon event alone?
2. What makes a scheduled task's *target path* a key detail in persistence investigation?
3. Why preserve raw `.evtx` exports before remediation actions?