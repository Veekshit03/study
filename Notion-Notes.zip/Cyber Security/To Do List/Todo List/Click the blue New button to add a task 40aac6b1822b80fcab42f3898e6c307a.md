# Click the blue New button to add a task

Due date: October 31, 2026
Status: Not started